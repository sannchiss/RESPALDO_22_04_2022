<?php

/**
 * Plugin Name: FedEx Envios Mexico
 * Plugin URI: https://fedex.com
 * Description: FedEx Envios Chile
 * Version: 1.0
 * Author: Sannchiss Pérez
 * Author URI: https://fedex.com
 * Text Domain: FedexPlugin
 * Domain Path: /lenguages
 * Licence: GPL2
 * 
 * Plugin de Software libre
 *
 * @package FedexPlugin
 */
/**
 * Returns the main instance of WC.
 *
 * @since  1.0
 * @return FedexPlugin
 */

defined('ABSPATH') || exit;

//Constante de la ruta del plugin de nombre: PLUGIN_DIR_PATH
define('PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));

class FedexPlugin
{

    public function __construct()
    {


        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
        $this->table_name = $table_prefix . 'fedex_shipping_intra_MX_configuration';


       // add_action('plugins_loaded', array($this, 'load_plugin_textdomain'));
        add_action('admin_menu', array($this, 'fedex_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
/*         add_action('wp_head', array($this, 'ajaxUrl'));

 */     add_action('wp_ajax_load_configuration', array($this, 'load_configuration'));
        add_action('wp_ajax_save_configuration', array($this, 'save_configuration'));
        /*add_action('admin_init', array($this, 'register_settings'));
        add_action('woocommerce_shipping_init', array($this, 'fedex_shipping_method'));
        add_filter('woocommerce_shipping_methods', array($this, 'add_fedex_shipping_method'));
        add_action('woocommerce_checkout_update_order_meta', array($this, 'save_shipping_method_data')); */


        $this->includes();
        $this->init();

        
    }


    public function includes()
    {
        require_once PLUGIN_DIR_PATH . 'includes/helpers-menu.php';
        require_once PLUGIN_DIR_PATH . 'includes/helpers-createTables.php';

     
    }

    public function init()
    {

        $init = new createTables();

        register_activation_hook(__FILE__, array($init, 'configuration'));



    }

    /**
     * The single instance of the class.
     *
     * @var FedexPlugin
     * 
     * @since 1.0
     *  */

    protected static $_instance = null;

    /**
     * Main FedexPlugin Instance.
     *
     * Ensures only one instance of FedexPlugin is loaded or can be loaded.
     *
     * @since 1.0
     * @static
     * @return FedexPlugin - Main instance.
     */

    public static function instance(){
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Cloning is forbidden.
     *
     * @since 1.0
     */

    public function __clone(){
        _doing_it_wrong(__FUNCTION__, __('No está permitido clonar esta instancia.', 'FedexPlugin'), '1.0');
    }

    /**
     * Unserializing instances of this class is forbidden.
     *
     * @since 1.0
     */


    public function __wakeup(){
        _doing_it_wrong(__FUNCTION__, __('No está permitido deserializar esta instancia.', 'FedexPlugin'), '1.0');
    }

    /**
     * Load the plugin text domain for translation.
     *
     * @since 1.0
     */

    public function load_plugin_textdomain(){
        load_plugin_textdomain('FedexPlugin', false, dirname(plugin_basename(__FILE__)) . '/lenguages');
    }

    /**
     * Register the Fedex Shipping Method.
     *
     * @since 1.0
     */

    public function fedex_shipping_method(){
        require_once PLUGIN_DIR_PATH . 'includes/class-fedex-shipping-method.php';
    }

    /**
     * Add the Fedex Shipping Method to WooCommerce.
     *
     * @since 1.0
     * @param array $methods
     * @return array
     */


     /**
      * función que agrega el menú de configuración
      */

      public function fedex_menu()
      {

        
        $menus = [];

        $menus[] = [
            'pageTitle' => 'FedEx Chile',
            'menuTitle' => 'E-commerce Mexico',
            'capability' => 'manage_options',
            'menuSlug' =>   'FX_MENU',
            'menu_slug'  =>  plugin_dir_path(__FILE__) . 'view/pedidosInicio.php',  //Ruta absoluta
            'functionName' => null, //LLama a la función
            'iconUrl' => plugin_dir_url(__FILE__) . 'resources/img/Fedex-GroundIconWP.png',  //Ruta absoluta
            'position' => 19
        ];

        addMenusPanel($menus);

        $submenu = [];

        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Gestor de Envíos',
            'menu_title'  => 'Gestor de Envíos',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/pedidosInicio.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];


        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Envios confirmados',
            'menu_title'  => 'Envios confirmados',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/enviosConfirmados.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];


        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Retiros confirmados',
            'menu_title'  => 'Retiros confirmados',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/confirmacion.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];

        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Configuración',
            'menu_title'  => 'Configuración',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'views/configuracion.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];

        addSubMenusPanel($submenu);


      }

     public function enqueue_scripts()
      {

        /**Libreria para mensajes */
        wp_register_script( 'sweetalert2', '//cdn.jsdelivr.net/npm/sweetalert2@11', null, null, true );
        wp_enqueue_script('sweetalert2');


        wp_enqueue_script(
            'loadConfiguration',
            plugins_url('resources/js/loadConfiguration.js', __FILE__),
            array('jquery'),
            ['jquery'],
            '1.0',
            true
        );

        
        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
         wp_localize_script(
            'loadConfiguration',
            'ajaxurl',
            array(
                
                'urlConfiguration'   => plugins_url('routes.php?action=configuration', __FILE__),
            )
        ); 
            

      }

     public function enqueue_styles()
      {
        
        wp_enqueue_style( 'frontend-style', plugin_dir_url( __FILE__ ) . 'resources/css/bootstrap/css/bootstrap.min.css' );
        wp_enqueue_style( 'frontend-style', plugin_dir_url( __FILE__ ) . 'resources/css/bootstrap/css/bootstrap-grid.min.css' );
        wp_enqueue_style( 'frontend-style', plugin_dir_url( __FILE__ ) . 'resources/css/bootstrap/css/bootstrap-reboot.min.css' );
        wp_enqueue_style( 'frontend-style', plugin_dir_url( __FILE__ ) . 'resources/css/bootstrap/css/bootstrap-theme.min.css' );

      }

      public function load_configuration(){


        $sql  = $this->wpdb->get_results("SELECT * FROM ".$this->table_name." WHERE id = 1");

        var_dump(json_encode($sql));


      }



     public function save_configuration(){

    
       $data = $this->unserializeForm($_POST['inputs']);
    
    
       $collection = array(
           'accountNumber' => $data['accountNumber'],
           'meterNumber' => $data['meterNumber'],
           'wskeyUserCredential' => $data['wskeyUserCredential'],
           'wskeyPasswordCredential' => $data['wskeyPasswordCre    dential'],
           'serviceType' => $data['serviceType'],
           'packagingType' => $data['packagingType'],
           'paymentType' => $data['paymentType'],
           'labelType' => $data['labelType'],
           'measurementUnits' => $data['measurementUnits'],
           'environment' => $data['environment'],
       );
    


       $sql  = $this->wpdb->get_results("SELECT * FROM ".$this->table_name." WHERE id = 1");

      

        if(count($sql) > 0){

           $this->wpdb->update($this->table_name, $collection, array('id' => 1));

           print "Se actualizo la configuración";

       }else{

           $this->wpdb->insert($this->table_name, $collection);

           print "Se guardo la configuración";
         
        } 
    
       
    }
  


   public function unserializeForm($form)
    {

        $strArray = explode("&", $form);
        $data = [];
        foreach($strArray as $item){
            $array = explode("=", $item);
            $data[] = $array;
        }

        $returndata = [];
        foreach ($data as $key => $value) {
            
            $returndata[$value[0]] = $value[1];
 
        } 

        return $returndata;


    }





}

/*Instantiate class*/

$GLOBALS['fedexPlugin'] = new fedexPlugin();