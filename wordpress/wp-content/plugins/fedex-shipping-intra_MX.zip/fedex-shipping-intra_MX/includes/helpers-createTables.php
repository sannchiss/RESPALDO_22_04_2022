<?php


class createTables{


    public function __construct(){

        global $wpdb;
        global $table_prefix;
        global $confCharset;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
        $this->confCharset = $confCharset = $this->wpdb->get_charset_collate();

    }

    public function configuration(){
       
        $tabla = $this->table_prefix . 'fedex_shipping_intra_MX_configuration';

        $sql = "CREATE TABLE IF NOT EXISTS $tabla (
            id INT(11) NOT NULL AUTO_INCREMENT,
            accountNumber VARCHAR(150),
            meterNumber VARCHAR(150),
            wskeyUserCredential VARCHAR(150),
            wskeyPasswordCredential VARCHAR(150),
            serviceType VARCHAR(100),
            packagingType VARCHAR(100),
            paymentType VARCHAR(50),
            labelType VARCHAR(50),
            measurementUnits VARCHAR(100),
            environment VARCHAR(50),

            PRIMARY KEY (id)
        ) $this->confCharset;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        //VACIAR LA TABLA SI CONTIENEN DATOS
        $sql = "TRUNCATE " . $tabla;
        $this->wpdb->query($this->wpdb->prepare($sql));
        /******************************************* */
        

    }





}