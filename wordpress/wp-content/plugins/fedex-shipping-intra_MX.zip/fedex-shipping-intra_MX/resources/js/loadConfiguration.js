 (function($) {

    $(document).ready(function() {

        


        $.ajax({

            url: 'admin-ajax.php',
            type: 'POST',
            data: {
                'action': 'load_configuration',
            },
            success: function(data) {
                
                var data = JSON.parse(data);
                console.log(data);

                response.forEach(element => {

                    console.log(element.accountNumber);

                   /*  if (element.name == 'accountNumber') {
                        $('#accountNumber').val(element.value);
                    }

                    if (element.name == 'meterNumber') {
                        $('#meterNumber').val(element.value);
                    }

                    if (element.name == 'key') {
                        $('#key').val(element.value);
                    }
 */
                   
                    
                });

                /* var response = jQuery.parseJSON(data);

                console.log(response.accountNumber); */

                /* if (response.status == 'success') {

                    $('#configuration').html(response.data);

                } else {

                    alert('Error al cargar la configuración');

                } */


            },
            error: function(error) {
                    
                    console.log(error);
    
                }


        });


//Envio de formulario de configuración datos cliente
jQuery('#configuration').on('submit', function(e) {
    e.preventDefault();


    let inputs = $("#configuration").serialize();
   
 
    $.ajax({
        url: 'admin-ajax.php', // Url to which the request is send
        type: 'POST',
        data: {

            'inputs': inputs, 
            'action': 'save_configuration'
        },
        success: function(data) {
            console.log(data);
            Swal.fire({
                title: 'Success',
                text: data,
                icon: 'success',
                confirmButtonText: 'Cerrar'
              })
        },
        error: function(data) {
            console.log(data);
            Swal.fire({
                title: 'Error',
                text: 'Error al guardar la configuración',
                icon: 'error',
                confirmButtonText: 'Cerrar'
              })
        }

    }); 



});  
    
    });

})(jQuery);

 