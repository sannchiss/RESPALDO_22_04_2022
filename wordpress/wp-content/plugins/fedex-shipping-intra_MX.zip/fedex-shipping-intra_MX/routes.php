<?php

/* require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php'; */

require_once 'controllers/Controller.php';
require_once 'controllers/configurationController.php';


if(isset($_GET['action'])){
    $action = $_GET['action'];

    switch($action){

        case 'configuration':

            $configurationController = new ConfigurationController();
            $configurationController->configuration($_POST);
            break;
        case 'save':
            $configurationController = new ConfigurationController();
            $configurationController->save();
            break;
        default:
            $configurationController = new ConfigurationController();
            $configurationController->configuration();
            break;
    }

}   else{
    $action = 'index';
}