(function($) {

$(document).ready(function() {

    /* ********************************************************************************************************************************* */

    //CARGA ENVÍO EN VENTANA FLOTANTE
    $(document).on('click', '#cargarEnvio', function() {

        numberOrder = $(this).data('order')
        customerid = $(this).data('customerid');

        let url = fdx_script_obj.urlCrearEnvio;


        $.ajax({
            type: "POST",
            url: url,
            data: {

                'numberOrder': numberOrder
            },
            beforeSend: function() {
                /*
                 * Esta función se ejecuta durante el envió de la petición al
                 * servidor.
                 * */

            },
            complete: function(data) {
                /*
                 * Se ejecuta al termino de la petición
                 * */


            },
            success: function(data) {

                let obj = jQuery.parseJSON(data);
                 let direccion = obj._billing_address_2 == undefined ? obj._billing_address_1 : obj._billing_address_1 + " " + obj._billing_address_2;
               // let direccion = obj._billing_address_1 + " " + obj._billing_address_2;
                let dirCut = String(direccion).substr(0, 40);
                //Nota de la compra
                let notaCut = obj.post_excerpt == undefined ? String(direccion).substr(0, 100) : String(obj.post_excerpt).substr(0, 100);

                let nombre = obj._billing_first_name + " " + obj._billing_last_name;
                let nameCut = String(nombre).substr(0, 40);

                let contacto = obj._billing_first_name + " " + obj._billing_last_name;
                let ContactCut = String(contacto).substr(0, 40);

                let comuna = obj._billing_city == undefined ? obj._billing_comuna : obj._billing_city;

                $('#CLIENTE_REFERENCIA').val(numberOrder);
                $('#NOMBRE_DESTINATARIO').val(nameCut);
                $('#DIRECCION_DESTINATARIO').val(dirCut);
                $('#NOTAS_DESTINATARIO').val(notaCut);
                $('#CODIGO_POSTAL_DESTINATARIO').val(obj._billing_postcode);
                $('#PERSONA_CONTACTO_DESTINATARIO').val(ContactCut);
                $('#POBLACION_DESTINATARIO').val(comuna);
                $('#TELEFONO_CONTACTO_DESTINATARIO').val(obj._billing_phone);
                $('#EMAIL_DESTINATARIO').val(obj._billing_email);

                $('#numberOrder').html(numberOrder);

                if(obj.bultoPedido == 'Si'){
                    $('#NUMERO_BULTOS').val(1);

                }else {
                    $('#NUMERO_BULTOS').val("");
                }

                //Covierto Entero
                let peso = parseFloat(obj.PESO_ENVIO);
                //seteo input
                $('#KILOS').val(isNaN(peso.toFixed(2)) ? 0 : peso.toFixed(2));
                //Covierto Entero
                let volumen = parseFloat(obj.VOLUMEN_ENVIO);
                //seteo input
                $('#VOLUMEN').val(isNaN(volumen.toFixed(3)) ? 0.01 :  volumen.toFixed(3) );

                $('#loadEnvio').modal('show');


                /*
                 * Se ejecuta cuando termina la petición y esta ha sido
                 * correcta
                 * */
            },
            error: function(data) {
                /*
                 * Se ejecuta si la peticón ha sido erronea
                 * */
                alert("Problemas al tratar de enviar el formulario");
            }
        });
        // Nos permite cancelar el envio del formulario
        return false;


    });


    /* ********************************************************************************************************************************* */

    //Envio de formulario de configuración datos cliente
    jQuery('#creatingConfig').on('submit', function(e) {
        

        let inputs = $("#creatingConfig").serialize();


        let atobMethod = btoa($("#contrasena").val());

        let impresora = $('#installedPrinterName').val();

        let url = fdx_script_obj.urlConfig;

        $.ajax({
            type: "POST",
            url: url,
            data: inputs + "&atobMethod=" + atobMethod,
            beforeSend: function() {
                /*
                 * Esta función se ejecuta durante el envió de la petición al
                 * servidor.
                 * */
                // btnEnviar.text("Enviando"); Para button 
                /*             send_config.val("");      // Para input de tipo button
                            send_config.text("Enviando");
                            send_config.attr("disabled", "disabled");
                 */



            },
            complete: function(data) {

                //  $('.send_config').text('Configurar').button("refresh");

                /*
                 * Se ejecuta al termino de la petición
                 * */
                /*             send_config.val("");
                            send_config.text("Completo");
                            send_config.removeAttr("disabled");
                            send_config.attr("disabled", "");
                 */



            },
            success: function(data) {


                $.confirm({
                    title: "<b>Respuesta Configuración:</b>",
                    content: "<center> Se ha guardado la configuración de cuenta con exito! </center>",
                    type: 'green',
                    typeAnimated: true,
                    buttons: {
                        tryAgain: {
                            text: 'Aceptar',
                            btnClass: 'btn-success',
                            action: function() {

                                $("#contrasena").val("");
                                window.location.reload();

                                //     $('.send_config').text('Guardada').button("refresh");


                                /*                             $("#usuario").val("");                           
                                                            $("#cuenta_cliente").val("");
                                 */
                            }
                        },
                        close: function() {



                        }
                    }
                });




            },
            error: function(data) {
                /*
                 * Se ejecuta si la peticón ha sido erronea
                 * */
                alert("Problemas al tratar de enviar el formulario");
            }
        });
        // Nos permite cancelar el envio del formulario
        return false;


    });



    /* ********************************************************************************************************************************* */

        /* CAMPO AUTOCOMPLETE DE CUENTA POBLACIÓN/COMUNA */

        let url = fdx_script_obj.urlCompLocation;

        $('input.typeaheadLocation').typeahead({
            items: 80, //Cantidad de elementos mostrados en lista
            minChars: 0,
            source: function(query, process) {

                $.get(url, { query: query }, function(data) {

                    objects = [];
                    labelCiudad = {};

                    //Cliclo para llenar el autocomplete
                    $.each(data, function(i, item) {
                        ///console.log(item.empresa)
                        var queryLabel = item.ciudad;
                        var nameCiudad = item.ciudad;
                        //console.log(nameCompany);
                        labelCiudad[queryLabel] = item;
                        objects.push(queryLabel);
                    });

                    process(objects);
                }, 'json')
            },

            updater: function(queryLabel) {

                var item = labelCiudad[queryLabel];
                var input_label = queryLabel;
                //$('#hiddeEmpresaid').val(item.empresa);
                $('.postalCode').val(item.codigo);
                return input_label;

            }

        });





});

})(jQuery);