/* ********************************************************************************************************************************* */
(function($) {

jQuery(document).ready(function() {

    let urlConfig = load_obj.urlLoadConfig;
    var passDeco = null;

    $.ajax({

        type: 'POST',
        url: urlConfig,
        data: null,

        success: function(data) {

            let obj = jQuery.parseJSON(data);

            console.log(obj);

            $.each(obj, function(i, item) {

                passDeco = atob(item.contrasena);

            });



        },
        error: function(error) {

            console.log("ERROR:" + error);

        }

    });



    jQuery('#creatingSend').on('submit', function(e) {
        e.preventDefault();

        // disable button
        $('.send_order').prop("disabled", true);
        // add spinner to button
        $('.send_order').html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Cargando...'
        );

        let inputs = $("#creatingSend").serializeArray();
        let clienteRef = $('#CLIENTE_REFERENCIA').val();
        let bultos = $('#NUMERO_BULTOS').val();
        let volumen = $('#VOLUMEN').val();

        console.log(inputs);


        let url = call_services_obj.urlDocEnvio;

        let data = {

            'inputs': inputs,
            'passDeco': passDeco

        };


        $.ajax({
            type: "POST",
            url: url,
            data: data,

            beforeSend: function(data) {


                /*  
                 * Esta función se ejecuta durante el envió de la petición al
                 * servidor.
                 * */
                // btnEnviar.text("Enviando"); Para button 
            },
            complete: function(data) {



                /*
                 * Se ejecuta al termino de la petición
                 * */


            },
            success: function(data) {

                if((isJson(data)) == true ){

                    let obj = jQuery.parseJSON(data);

                    $.each(obj, function (i, item) {

                        if (item.respuestaDocuemtarEnvio.resultado == "OK") {

                            $.confirm({
                                title: "<b>" + item.respuestaDocuemtarEnvio.mensaje + "</b>",
                                content: "<centre>La Orden de transaporte generada: <b>" + item.respuestaDocuemtarEnvio.numero_envio + "</b></centre>",
                                type: 'green',
                                typeAnimated: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Aceptar',
                                        btnClass: 'btn-success',
                                        action: function () {

                                            $('#loadEnvio').modal('hide');
                                            $('#NUMERO_BULTOS').val('');

                                            insertEnvioBD(item, clienteRef);
                                            $('#enviosCarga-table').DataTable().ajax.reload();

                                            $('.send_order').prop("disabled", false);

                                            $('.send_order').html(
                                                '<span class="badge badge-pill badge-primary"></span> Procesado'
                                            );



                                        }
                                    },
                                    close: function () {

                                        $('#loadEnvio').modal('hide');
                                        $('#enviosCarga-table').DataTable().ajax.reload();


                                    }
                                }
                            });

                        } else {


                            $.confirm({
                                title: "<b>" + item.respuestaDocuemtarEnvio.mensaje + "</b>",
                                content: "",
                                type: 'red',
                                typeAnimated: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Aceptar',
                                        btnClass: 'btn-success',
                                        action: function () {

                                            $('.send_order').prop("disabled", false);

                                            $('.send_order').html(
                                                '<span class="badge badge-pill badge-primary"></span>Reintentar'
                                            );

                                        }
                                    },
                                    close: function () {

                                        $('.send_order').prop("disabled", false);

                                        $('.send_order').html(
                                            '<span class="badge badge-pill badge-primary"></span>Reintentar'
                                        );

                                    }
                                }
                            });

                        }



                    });

                

                }else{

                    $.confirm({
                        title: 'Error de Configuración!',
                        content: "<b>Error en la configuración de datos del remitente</b>",
                        type: 'red',
                        typeAnimated: true,
                        buttons: {
                            close: function() {
                                //$('#loadEnvio').modal('hide');
                                 $('#enviosCarga-table').DataTable().ajax.reload();
                                // disable button
                                $('.send_order').prop("disabled", false);
                                // add spinner to button
                                $('.send_order').html(
                                    '<span class="badge badge-pill badge-primary"></span>GESTIONAR ENVÍO'
                                );
                                $('#enviosCarga-table').DataTable().ajax.reload(); 
                            }
                        }
                    });



                }


            /*************************************************************************** */
                //Valida si la respuesta es o no Json
                function isJson(str) {
                    try {
                        JSON.parse(str);
                    } catch (e) {
                        return false;
                    }
                    return true;
                }
            /*************************************************************************** */
                /*
                * Se ejecuta cuando termina la petición y esta ha sido
                * correcta
                * */            },
            error: function(errorMessage) {

                console.log("ERROR" + errorMessage);
                

            }
        }).done(function() {


        });


        // Nos permite cancelar el envio del formulario
        return false;


        function insertEnvioBD(item, clienteRef) {


            let url = fdx_script_obj.urlInsertBD;
            let impresionEtq = 0;
            let solicitudReco = 0;

            //Inserción dentro del Json los datos de la tabla envios_ecommerce
            item.respuestaDocuemtarEnvio.order = clienteRef;
            item.respuestaDocuemtarEnvio.impresionEtq = impresionEtq;
            item.respuestaDocuemtarEnvio.solicitudRecogida = solicitudReco;


            $.ajax({
                type: "POST",
                url: url,
                data: { inputs: item },
                beforeSend: function () {
                    /*  
                    * Esta función se ejecuta durante el envió de la petición al
                    * servidor.
                    * */
                    // btnEnviar.text("Enviando"); Para button 
                },
                complete: function (data) {

                    /*
                    * Se ejecuta al termino de la petición
                    * */

                    $('#enviosCarga-table').DataTable().ajax.reload();



                },
                success: function (data) {

                    console.log(data);
                    $('#enviosCarga-table').DataTable().ajax.reload();


                },
                error: function (xhr, textStatus, errorMessage) {

                    console.log("ERROR" + errorMessage + textStatus + xhr);

                }
            });


        }


    });



});

})(jQuery);