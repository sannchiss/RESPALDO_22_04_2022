/* jQuery(function($) {

    let costoFedEx = 5500;

    var customercountry = jQuery('#billing_address_1').val();
    alert(customercountry); */




jQuery(document).ready(function($) {


    $('#add_gift_box').click(function() {

        let ischecked = $(this).is(":checked"); //Verificamos que esté chequeado


        let url = cotizador_obj.ajax_url;


        if (ischecked) {

            let data = {
                action: 'loadPrice',
                state: '200',
                price: '6987'
            };
            $.ajax({
                type: 'POST',
                url: url,
                data: data,
                success: function(code) {
                    console.log(code);
                    //   jQuery('body').trigger('update_checkout');
                },
                dataType: 'html'
            });


        }

    });






});





/*  $(document.body).on('change', 'select[name=billing_address_1]', function() {
     console.log('Country changed: ' + $(this).val());
     // Here run your function or code
 });



 jQuery('#billing_address_1').change(function() {
     var customercountry = jQuery('#billing_address_1').val();

     alert(customercountry);
     if (customercountry == "") {

         alert("Null");
         //jQuery("#billing_phone_field > label > abbr").hide();
     } else {
         //jQuery("#billing_phone_field > label > abbr").show();
     }
 }); */



//});