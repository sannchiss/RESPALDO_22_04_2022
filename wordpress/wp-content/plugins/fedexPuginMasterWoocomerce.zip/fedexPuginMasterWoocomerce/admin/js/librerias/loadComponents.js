(function($) {

$(document).ready(function() {

    var componente = 'aler://print/asPrintService%true&actualizador%FEDEX';
    console.log('Entra en carga componete');

    try {
        //comprueba si está levantado
        var puertoLoad = '62341';
        if (document.location.protocol == 'https:') {
            puertoLoad = '62341';
        } else {
            puertoLoad = '62342';
        }
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open('GET', '//impresion2.alertran.net:' + puertoLoad + '/printService/ping', false);
        console.log(xmlHttp.readyState);
        console.log(xmlHttp.status);
        xmlHttp.send(null);
        console.log(xmlHttp.responseText);
    } catch (error) {
        //si no lo está lo levanta
        var iframe = window.document.getElementById('iframeZPL');
        if (!iframe) {
            iframe = window.document.createElement('iframe');
            iframe.id = 'iframeZPL';
            iframe.style = 'display: block;';
            window.document.body.appendChild(iframe);
        }
        iframe.src = componente;
    }

    /*****************************************************************/

    //Carga configuracion Inicial

    let url = load_obj.urlLoadConfig;

    $.ajax({

        type: 'POST',
        url: url,
        data: null,

        success: function(data) {

            let obj = jQuery.parseJSON(data);


            $.each(obj, function(i, item) {

                $('#cuenta_cliente').val(item.cuentaGTS);
                $('#usuario').val(item.usuario);
                $("#tipo_entorno").val(item.ENTORNO);
                $("#tipo_impresion").val(item.TIPO_ETIQUETAS);
                $("#impresora").val(item.NOMBRE_IMPRESORA);


                if (item.NOMBRE_IMPRESORA != "" && (item.TIPO_ETIQUETAS == "EPL" || item.TIPO_ETIQUETAS == "ZPL")) {

                    document.getElementById("divImpresora").style.display = "block";

                } else {

                    document.getElementById("divImpresora").style.display = "none";

                }


                $("#select_bultos").val(item.BULTO_POR_PEDIDO);

            });


        },
        error: function(erorr) {

            console.log("ERROR:" + erorr);

        }


    });

    /*Carga Listado de impresoras Fomulario de configuración*/
/*     let urlLoadPrint = load_obj.urlLoadPrint;

    let puertoImpresora = '62341';

    if (document.location.protocol == 'https:') {
        puertoImpresora = '62341';
        //   console.log("ingreso https")
    } else {
        puertoImpresora = '62342';
        //    console.log("no ingreso https")
    }

    console.warn(" Puerto de entrada" + puertoImpresora);

    $.ajax({

        type: 'GET',
        url: urlLoadPrint,
        data: { puerto: puertoImpresora },

        success: function(data) {

            console.warn(data);

            let obj = jQuery.parseJSON(data);

            $.each(obj.printers, function(i, item) {

                console.log(item);

                document.getElementById("impresora").innerHTML += "<option value='" + item + "'>" + item + "</option>";

            });


        },
        error: function(erorr) {

            console.log("ERROR:" + erorr);

        }


    }); */

    /*****************************************************/

    $("#loadEnvio").on("hidden.bs.modal", function() {

        $('.send_order').prop("disabled", false);

        $('.send_order').html(
            '<span class="badge badge-pill badge-primary"></span>GESTIONAR ENVÍO'
        );

        //   $('#enviosCarga-table').DataTable().ajax.reload();

        $('#NUMERO_BULTOS').val('');
        $('#KILOS').val('');
       // $('#VOLUMEN').val('');
    });



});


})(jQuery);