(function($) {

$(document).ready(function () {

    let urlConfig = load_obj.urlLoadConfig;
    var passDeco = null;

    $.ajax({

        type: 'POST',
        url: urlConfig,
        data: null,

        success: function (data) {

            let obj = jQuery.parseJSON(data);

            console.log(obj);

            $.each(obj, function (i, item) {

                passDeco = atob(item.contrasena);

            });

        },
        error: function (error) {

            console.log("ERROR:" + error);

        }

    });


    /*********DATATABLE CARGA DE PEDIDOS DE WOOCOMERCE************ */

    let urlPedidos = load_data_obj.urlLoadPedidos;


    var dataTablePedidos = $('#enviosCarga-table').dataTable({

        pageLength: 20,
        order: [
            [1, "desc"]
        ],
        scrollCollapse: true,

        columnDefs: [{
            'targets': [4, 5, 6, 7],
            'orderable': false,
            'width': "15%"
        }],



        /* dom: 'lBfrtip',
         buttons: [
            'copy', 'csv', 'excel', 'pdf'
        ], */
        "language": {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending": true,
                "sSortDescending": true
            }

        },



        ajax: {
            "url": urlPedidos,
            "type": "GET",
            "dataSrc": '',

        },
        columns: [{

            render: function (data, type, row) {

                //Nombre comprador
                return "<h5><span class='badge badge-secondary'>" + row.nombre + "</span></h5>";

            }

        },
        {

            render: function (data, type, row) {

                //Fecha de compra
                return "<h6><span class='badge badge-secondary'>" + row.date_created + "</span></h6>";


            }


        },
        {

            render: function (data, type, row) {

                //Ciudad
                return "<h6><span class='badge badge-secondary'>" + row.state + "</span></h6>";

            }


        },
        {


            render: function (data, type, row) {

                //cantidad Item de compra
                return "<center><h5><span class='badge badge-info'>" + row.num_items_sold + "</span></h5></center>";


            }



        },

        {
            render: function (data, type, row) {
                //DETALLE DE LA COMPRA
                return "<button type='button' class='btn btn-info' id='detalle' data-order = '" + row.order_id + "' data-customerid = '" + row.customer_id + "' >Info</button>";

            }
        },
        {
            render: function (data, type, row) {

                //MENSAJE DE ESTADO DEL ENVIO

                if (row.RESPUESTA_SERV == null) {

                    return "<div class='alert alert-danger' role='alert'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-info-lg' viewBox='0 0 16 16'><path d='m10.277 5.433-4.031.505-.145.67.794.145c.516.123.619.309.505.824L6.101 13.68c-.34 1.578.186 2.32 1.423 2.32.959 0 2.072-.443 2.577-1.052l.155-.732c-.35.31-.866.434-1.206.434-.485 0-.66-.34-.536-.939l1.763-8.278zm.122-3.673a1.76 1.76 0 1 1-3.52 0 1.76 1.76 0 0 1 3.52 0z'/></svg>Pendiente por envío</div>";

                } else {

                    return "<div class='alert alert-success' role='alert'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-check2-circle' viewBox='0 0 16 16'><path d='M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z'/><path d='M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z'/></svg>Inserción realizada<b> : #" + row.NUMERO_ENVIO + "</b></div>";


                }

            }
        },

        {
            render: function (data, type, row) {

                //CHECK PARA HABILITAR LA ENTREGA O LA CONFIRMACIÓN DE UNO O VARIOS ENVIOS

                if (row.RESPUESTA_SERV != null && row.ESTADO_ETIQUETA == 1) {

                    return "<center><div class='btn btn-info'><div class='custom-control custom-switch'><input type='checkbox' name='checkOrden[]' value=" + row.NUMERO_ENVIO + "  class='custom-control-input' id=" + row.order_id + "><label class='custom-control-label' for=" + row.order_id + ">ORDEN: " + row.order_id + "</label></div></div></center>";


                } else {

                    // MUESTRA LA ORDEN DE COMPRA
                    return "<center><button type='' class='btn btn-outline-info' data-mdb-ripple-color='dark'>ORDEN: " + row.order_id + "</button></center>";
                }

            }
        },

        {
            render: function (data, type, row) {

                // OPCIONES PARA ENVIAR AL SERVICIO DOCUMENTAR ENVIO
                // O BIEN PARA LA IMPRESION DE ETIQUETAS

                if (row.RESPUESTA_SERV == null) {

                    return "<center><button type='button' class='btn btn-primary' id='cargarEnvio' data-customerid = " + row.customer_id + " data-order = " + row.order_id + "  >Enviar</button></center>";

                } else {

                    return "<center><div class='' role='toolbar' aria-label='Toolbar with button groups'><div class='btn-group mr-2' role='group' aria-label='Second group'><button type='button' class='imprimir badge badge-secondary' data-ot = " + row.NUMERO_ENVIO + " data-print='unique'><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='currentColor' class='bi bi-printer' viewBox='0 0 16 16'><path d='M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z'/><path d='M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2H5zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4V3zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2H5zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1z'/></svg></button><div class='btn btn-info'><div class='custom-control custom-switch'><input type='checkbox' name='checkImpMasivo[]' value=" + row.NUMERO_ENVIO + "  class='custom-control-input' id=s" + row.order_id + "><label class='custom-control-label' for=s" + row.order_id + "></label></div></div><button type='button' class='eliminar btn btn-danger' data-ot = " + row.NUMERO_ENVIO + "><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-trash-fill' viewBox='0 0 16 16'><path d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z'></path></svg></button></div></div></center>";


                }

            }
        }


        ]


    });

    //SELECCIONAR DE MANERA MASIVA TODOS LOS PEDIDOS, TANTO PARA IMPRESIÓN COMO PARA CONFIRMACIÓN.

    $(".checkAllPrint").on("change", function () {

        if ($(this).hasClass('checked')) {
            dataTablePedidos.$('input[name="checkImpMasivo[]"]').prop('checked', false);


        } else {

            dataTablePedidos.$('input[name="checkImpMasivo[]"]').prop('checked', true);
        }

        $(this).toggleClass('checked');

    });


    $(".checkAllConfirm").on("change", function () {

        if ($(this).hasClass('checked')) {
            dataTablePedidos.$('input[name="checkOrden[]"]').prop('checked', false);


        } else {

            dataTablePedidos.$('input[name="checkOrden[]"]').prop('checked', true);
        }

        $(this).toggleClass('checked');

    });

    /*****************************************************************************************************************/


    $(document).on('click', '.btnActPedidos', function () {


        let urlPedidos = load_data_obj.urlLoadPedidos;


        dataTablePedidos.DataTable().ajax.url(urlPedidos + "&date_start=" + $('#fromDate').val() + "&date_end=" + $('#toDate').val()).load();




    });


    /* ********************************************************************************************************************************* */
    //IMPRESIÓN DE UN SOLO ENVÍO
    $(document).on('click', '.imprimir', function () {

        $(this).prop("disabled", true);
        // add spinner to button
        $(this).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'
        );

        let Ot = $(this).data('ot')

        let url = call_services_obj.urlImpresion;

        let data = {
            Ot: Ot,
            passDeco: passDeco
        };


        $.confirm({

            content: function () {

                var self = this;

                return $.ajax({

                    url: url,
                    data: data,
                    method: 'POST'
                }).done(function (data) {

                    self.setTitle('Mensaje');
                    self.setContent('Impresión emitida');
                    /*  self.setContentAppend('<br>Version: ' + response.version);
                        self.setTitle(response.name);
                     */

                    $('#enviosCarga-table').DataTable().ajax.reload();


                    let obj = jQuery.parseJSON(data);

                    obj.forEach(element => {

                        console.log(element.tipo_etiqueta);

                        if (element.tipo_etiqueta == 'PDF' || element.tipo_etiqueta == 'PDF2') {

                            let pdfWindow = window.open("");
                            pdfWindow.document.write("<embed width='100%' height='100%' src='data:application/pdf;base64, " + encodeURI(element.etiqueta) + "#toolbar=0&navpanes=0&scrollbar=0'>");


                        } else if (element.tipo_etiqueta == 'EPL' || element.tipo_etiqueta == 'ZPL') {

                            // console.log(element.etiqueta);

                            var puerto = '62341';

                            if (document.location.protocol == 'https:') {
                                puerto = '62341';
                                //   console.log("ingreso https")
                            } else {
                                puerto = '62342';
                                //    console.log("no ingreso https")
                            }
                            var etiquetaDecode = atob(element.etiqueta);
                            console.warn(etiquetaDecode);


                            var xmlHttp = new XMLHttpRequest();
                            xmlHttp.open('POST', '//impresion2.alertran.net:' + puerto + '/printService/print', true);
                            xmlHttp.setRequestHeader('Content-Type', 'text/plain');
                            xmlHttp.send(JSON.stringify({
                                'contenido': etiquetaDecode,
                                'printer': element.nombre_impresora,
                                'rutaBaseCliente': 'QzovQWxlcmNlLw==',
                                'usuario': 'woocommerce',
                                'printerFromPreferences': 'true'
                            }));
                            console.error(xmlHttp.responseText);

                        }


                    });



                }).fail(function () {
                    self.setContent('Algo salio mal, por favor vuelva a intentar');
                });
            }
        });


    });

    /* ********************************************************************************************************************************* */
    //Impresion masiva

    $(document).on('click', '.masivo', function () {


        var data = dataTablePedidos.$('input[name="checkImpMasivo[]"]').serializeArray();

        console.log(data);


        $('.masivo').prop("disabled", true);
        // add spinner to button
        $('.masivo').html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Cargando...'
        );


        //  let checkOrder = document.getElementsByName('checkImpMasivo[]')

        let length = data.length;

        let ids = new Array();

        for (var i = 0, n = length; i < n; i++) {

            // console.log( data[i].value );

            var envioComunicar = {
                'id_order': data[i].value
            };
            ids.push(envioComunicar);

        }

        console.log(ids);


        if (length > 0) {

            $.confirm({
                title: "<b>Cantidad para impresión seleccionada #" + length + "</b>",
                content: "",
                type: 'red',
                typeAnimated: true,
                buttons: {
                    tryAgain: {
                        text: 'Imprimir?',
                        btnClass: 'btn-warning',
                        action: function () {

                            // add spinner to button

                            $('.masivo').prop("disabled", false);


                            $('.masivo').html(
                                '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> IMPRESIÓN MASIVA'
                            );

                            let data = {

                                'ids': ids,
                                'passDeco': passDeco
                            };

                            let url = load_data_obj.urlImpMasivo;


                            $.confirm({
                                content: function () {
                                    var self = this;
                                    return $.ajax({
                                        url: url,
                                        data: data,
                                        method: 'POST'
                                    }).done(function (data) {

                                        self.setTitle('Mensaje');
                                        self.setContent('Impresión emitida');
                                        /*  self.setContentAppend('<br>Version: ' + response.version);
                                            self.setTitle(response.name);
                                         */

                                        let obj = jQuery.parseJSON(data);

                                        obj.forEach(element => {

                                            if (element.tipo_etiqueta == 'PDF' || element.tipo_etiqueta == 'PDF2') {

                                                console.log("Impresion PDF");
                                                let pdfWindow = window.open("");
                                                pdfWindow.document.write("<embed width='100%' height='100%' src='data:application/pdf;base64, " + encodeURI(element.etiqueta) + "#toolbar=0&navpanes=0&scrollbar=0'>");

                                            } else if (element.tipo_etiqueta == 'EPL' || element.tipo_etiqueta == 'ZPL') {

                                                // console.log(element.etiqueta);

                                                var puerto = '62341';

                                                if (document.location.protocol == 'https:') {
                                                    puerto = '62341';

                                                } else {
                                                    puerto = '62342';

                                                }
                                                var etiquetaDecode = atob(element.etiqueta);
                                                console.warn(etiquetaDecode);


                                                var xmlHttp = new XMLHttpRequest();
                                                xmlHttp.open('POST', '//impresion2.alertran.net:' + puerto + '/printService/print', true);
                                                xmlHttp.setRequestHeader('Content-Type', 'text/plain');
                                                xmlHttp.send(JSON.stringify({
                                                    'contenido': etiquetaDecode,
                                                    'printer': element.nombre_impresora,
                                                    'rutaBaseCliente': 'QzovQWxlcmNlLw==',
                                                    'usuario': 'woocommerce',
                                                    'printerFromPreferences': 'true'
                                                }));
                                                console.error(xmlHttp.responseText);

                                            }

                                        });

                                        $('#enviosCarga-table').DataTable().ajax.reload();


                                    }).fail(function () {
                                        self.setContent('Algo salio mal, por favor vuelva a intentar');
                                    });
                                }
                            });



                        }
                    },
                    close: function () {

                        $('.masivo').prop("disabled", false);


                        $('.masivo').html(
                            '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> IMPRESIÓN MASIVA'
                        );

                    }
                }
            });

        } else {


            $.confirm({
                title: 'Aviso',
                content: '<b>Debe selecciona para imprimir</b>',
                type: 'red',
                typeAnimated: true,
                buttons: {
                    tryAgain: {
                        text: 'Aceptar',
                        btnClass: 'btn-red',
                        action: function () {


                            $('.masivo').prop("disabled", false);
                            $('.masivo').html(
                                '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> IMPRESIÓN MASIVA'
                            );


                        }
                    },
                    close: function () {

                        $('.masivo').prop("disabled", false);
                        $('.masivo').html(
                            '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> IMPRESIÓN MASIVA'
                        );


                    }
                }
            });



        }

    });

    /**********************************************************************************************************************************/
    //BORRAR ENVIO
    $(document).on('click', '.eliminar', function () {

        $(this).prop("disabled", true);
        // add spinner to button
        $(this).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'
        );

        let Ot = $(this).data('ot');

        let url = load_data_obj.urlEliminar;

        $.confirm({
            title: 'Aviso',
            content: '<b>Deseas eliminar la OT: ' + Ot + '</b>',
            type: 'red',
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Aceptar',
                    btnClass: 'btn-red',
                    action: function () {

                        let data = {

                            'Ot': Ot,
                            'passDeco': passDeco
                        };

                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: url,
                                    data: data,
                                    method: 'POST'
                                }).done(function (data) {
                                    self.setTitle('Mensaje');
                                    self.setContent('OT Eliminada!');
                                    /*  self.setContentAppend('<br>Version: ' + response.version);
                                        self.setTitle(response.name);
                                     */

                                    $('#enviosCarga-table').DataTable().ajax.reload();
                                    $('#enviosConfir-table').DataTable().ajax.reload();


                                }).fail(function () {
                                    self.setContent('Algo salio mal, por favor vuelva a intentar');
                                });
                            }
                        });


                    }
                },
                close: function () {
                    $('#enviosCarga-table').DataTable().ajax.reload();
                    $('#enviosConfir-table').DataTable().ajax.reload();


                }
            }
        });

    });

    /* ********************************************************************************************************************************* */
    //CONFIRMACION DE LOS ENVIOS SELECCIONADOS

    $(document).on('click', '.confirmacion', function (event) {
        event.preventDefault();

        var data = dataTablePedidos.$('input[name="checkOrden[]"]').serializeArray();

        $(this).prop("disabled", true);
        // add spinner to button
        $(this).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Cargando...'
        );

        let length = data.length;

        let ids = new Array();

        for (var i = 0, n = length; i < n; i++) {

            // console.log( data[i].value );

            var envioComunicar = {
                'id_order': data[i].value
            };
            ids.push(envioComunicar);

        }


        if (ids.length == 0) {

            $.confirm({
                title: "<b>Aviso</b>",
                content: "<b>Debe seleccionar minimo (1) orden de compra</b>",
                type: 'red',
                typeAnimated: true,
                buttons: {
                    tryAgain: {
                        text: 'Aceptar',
                        btnClass: 'btn-red',
                        action: function () {

                            $('#enviosCarga-table').DataTable().ajax.reload();
                            $('.confirmacion').prop("disabled", false);

                            $('.confirmacion').html(
                                '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                            );


                        }
                    },
                    close: function () {

                        $('#enviosCarga-table').DataTable().ajax.reload();

                        $('.confirmacion').prop("disabled", false);

                        $('.confirmacion').html(
                            '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                        );



                    }
                }
            });

        } else {


            console.log(ids);

            let url = call_services_obj.urlEntrega;

            let data = {

                'ids': ids,
                'passDeco': passDeco
            };

            $.confirm({

                content: function () {

                    var self = this;

                    return $.ajax({

                        url: url,
                        data: data,
                        method: 'POST'

                    }).done(function (data) {

                        self.setTitle('Mensaje');
                        self.setContent('Confirmación de retiro realizada');
                        /*  self.setContentAppend('<br>Version: ' + response.version);
                            self.setTitle(response.name);
                         */

                        let obj = jQuery.parseJSON(data);

                        obj.forEach(element => {

                            if (element.respuestaEntregaRecogida.resultado == "ERROR") {

                                $.confirm({
                                    title: "<b>Error creando el manifiesto</b>",
                                    content: element.respuestaEntregaRecogida.mensaje + '. Expedicione(s): ' + element.respuestaEntregaRecogida.expedicion,
                                    type: 'red',
                                    typeAnimated: true,
                                    buttons: {
                                        tryAgain: {
                                            text: 'Aceptar',
                                            btnClass: 'btn-success',
                                            action: function () {

                                                $('#enviosCarga-table').DataTable().ajax.reload();
                                                $('#enviosConfir-table').DataTable().ajax.reload();

                                                $('.confirmacion').prop("disabled", false);

                                                $('.confirmacion').html(
                                                    '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                                                );


                                            }
                                        },
                                        close: function () {

                                            $('#enviosCarga-table').DataTable().ajax.reload();
                                            $('#enviosConfir-table').DataTable().ajax.reload();

                                            $('.confirmacion').prop("disabled", false);

                                            $('.confirmacion').html(
                                                '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                                            );


                                        }
                                    }
                                });


                            } else {

                                obj.forEach(element => {

                                    //console.log(element.respuestaEntregaRecogida.manifiesto);

                                    $.confirm({
                                        title: "<b>Se ha asignado a la recogida: " + element.respuestaEntregaRecogida.recogida + "</b>",
                                        content: "",
                                        type: 'green',
                                        typeAnimated: true,
                                        buttons: {
                                            tryAgain: {
                                                text: 'Visualizar',
                                                btnClass: 'btn-success',
                                                action: function () {

                                                    let pdfWindow = window.open("");
                                                    pdfWindow.document.write("<embed width='100%' height='100%' src='data:application/pdf;base64, " + encodeURI(element.respuestaEntregaRecogida.manifiesto) + "#toolbar=0&navpanes=0&scrollbar=0'>");

                                                    $('#enviosCarga-table').DataTable().ajax.reload();
                                                    $('#enviosConfir-table').DataTable().ajax.reload();
                                                    $('.confirmacion').prop("disabled", false);

                                                    $('.confirmacion').html(
                                                        '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                                                    );



                                                }
                                            },
                                            close: function () {

                                                $('#enviosCarga-table').DataTable().ajax.reload();
                                                $('#enviosConfir-table').DataTable().ajax.reload();
                                                $('.confirmacion').prop("disabled", false);

                                                $('.confirmacion').html(
                                                    '<span class="" role="status" aria-hidden="true"></span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16"><path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" /><path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" /></svg> CONFIRMAR ENVÍOS'
                                                );


                                            }
                                        }
                                    });



                                });

                            }


                        });

                    }).fail(function () {
                        self.setContent('Algo salio mal, por favor vuelva a intentar');
                    });
                }
            });


        }

    });



    /*************************************************************************************************************************************/

    /*********DATATABLE RECOGIDAS************ */

    let urlReco = load_data_obj.urlRecogida;
    let dataTableReco = $('#recogidas-table').dataTable({

        pageLength: 20,
        order: [
            [2, "desc"]
        ],
        scrollCollapse: true,

        columnDefs: [{
            'targets': [ 3 ],
            'orderable': false,
            'width': "15%"
        }],

        "language": {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }

        },
        ajax: {
            "url": urlReco,
            "type": "GET",
            "dataSrc": '',

        },
        columns: [{


            render: function (data, type, row) {

                //Nombre comprador
                return "<h5><span class='badge badge-secondary'>" + row.id + "</span></h5>";

            }

        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<h5><span class='badge badge-secondary'>" + row.created_at + "</span></h5>";

            }

        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<h5><span class='badge badge-secondary'>" + row.ID_RECOGIDA + "</span></h5>";

            }


        },
        {
            render: function (data, type, row) {

                return "<button type='button' id='impRecogida' data-recogida ='" + row.ID_RECOGIDA + "'class='editar edit-modal btn btn-primary'>Recogida</button>";
            }
        },


        ]
    });


    $(document).on('click', '#impRecogida', function () {

        let url = load_data_obj.urlImpRecogida;

        let numeroRetiro = $(this).data('recogida')

        console.log(numeroRetiro);

        $.ajax({
            type: 'POST',
            url: url,
            data: { orden: numeroRetiro },

            success: function (data) {

                let obj = jQuery.parseJSON(data);

                obj.forEach(element => {
                    // console.log(element.MANIFIESTO_64Bytes);
                    let pdfWindow = window.open("");
                    pdfWindow.document.write("<embed width='100%' height='100%' src='data:application/pdf;base64, " + encodeURI(element.MANIFIESTO_64Bytes) + "#toolbar=0&navpanes=0&scrollbar=0'>");

                });


            },
            error: function (errorThrown) {
                //    console.log(errorThrown);
            }


        });


    });


    /************DATATABLE ENVIOS CONFIRMADOS************ */

    let urlEnvConf = load_data_obj.urlEnvConfir;
    let dataTableEnvConf = $('#enviosConfir-table').dataTable({

        pageLength: 20,
        order: [
            [1, "desc"]
        ],
        scrollCollapse: true,

        columnDefs: [{
            'targets': [4, 5, 6],
            'orderable': false,
            'width': "15%"
        }],



        "language": {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }

        },
        ajax: {
            "url": urlEnvConf,
            "type": "GET",
            "dataSrc": '',

        },
        columns: [{

            render: function (data, type, row) {

                //Nombre comprador
                return "<center><h5><span class='badge badge-secondary'>" + row.ID_ORDER + "</span></h5></center>";


            }



        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<center><h5><span class='badge badge-secondary'>" + row.NUMERO_ENVIO + "</span></h5></center>";


            }


        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<center><h5><span class='badge badge-secondary'>" + row.created_at + "</span></h5></center>";


            }


        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<center><h5><span class='badge badge-success'>" + row.RESPUESTA_SERV + "</span></h5></center>";


            }

        },
        {

            render: function (data, type, row) {

                //Nombre comprador
                return "<center><h5><span class='badge badge-secondary'>" + row.CLIENTE_CENTRO + "</span></h5></center>";


            }


        },

        {
            render: function (data, type, row) {

                return "<center><button type='button' id='impEtiqueta' data-ot ='" + row.NUMERO_ENVIO + "'class='impEtiqueta edit-modal btn btn-primary'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-printer-fill' viewBox='0 0 16 16'><path d='M5 1a2 2 0 0 0-2 2v1h10V3a2 2 0 0 0-2-2H5zm6 8H5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1z'/><path d='M0 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-1v-2a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2H2a2 2 0 0 1-2-2V7zm2.5 1a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z'/></svg></button></center>";
            }
        },
        {
            render: function(data, type, row) {
                return "<center><button type='button' id='trakingEnvio' data-cuenta='" + row.CLIENTE_CENTRO + "' data-ot ='" + row.NUMERO_ENVIO + "' data-entorno ='" + row.ENTORNO + "'class='trakingEnvio edit-modal btn btn-info'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-geo-alt-fill' viewBox='0 0 16 16'><path d='M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z'/></svg></button></center>";
            }
        }


        ]
    });



    /*************************************************************************** */

    /**REIMPRESION DE ETIQUETAS DE ENVIOS CONFIRMADOS */

    $(document).on('click', '#impEtiqueta', function () {


        $(this).prop("disabled", true);
        // add spinner to button
        $(this).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'
        );


        let url = call_services_obj.urlImpresion;

        let data = {
            'Ot': $(this).data('ot'),
            'flat': 'R',
            'passDeco': passDeco
        };

        $.ajax({
            type: 'POST',
            url: url,
            data: data,

            success: function (data) {

                let obj = jQuery.parseJSON(data);




                obj.forEach(element => {



                    if (element.tipo_etiqueta == 'PDF' || element.tipo_etiqueta == 'PDF2') {

                        console.log("Impresion PDF");
                        let pdfWindow = window.open("");
                        pdfWindow.document.write("<embed width='100%' height='100%' src='data:application/pdf;base64, " + encodeURI(element.etiqueta) + "#toolbar=0&navpanes=0&scrollbar=0'>");

                        $('#enviosConfir-table').DataTable().ajax.reload();



                    } else if (element.tipo_etiqueta == 'EPL' || element.tipo_etiqueta == 'ZPL') {

                        // console.log(element.etiqueta);

                        var puerto = '62341';

                        if (document.location.protocol == 'https:') {
                            puerto = '62341';

                        } else {
                            puerto = '62342';

                        }
                        var etiquetaDecode = atob(element.etiqueta);
                        console.warn(etiquetaDecode);


                        var xmlHttp = new XMLHttpRequest();
                        xmlHttp.open('POST', '//impresion2.alertran.net:' + puerto + '/printService/print', true);
                        xmlHttp.setRequestHeader('Content-Type', 'text/plain');
                        xmlHttp.send(JSON.stringify({
                            'contenido': etiquetaDecode,
                            'printer': element.nombre_impresora,
                            'rutaBaseCliente': 'QzovQWxlcmNlLw==',
                            'usuario': 'woocommerce',
                            'printerFromPreferences': 'true'
                        }));
                        console.error(xmlHttp.responseText);

                        $('#enviosConfir-table').DataTable().ajax.reload();


                    }



                });


            },

            complete: function () {

            },


            error: function (errorThrown) {
                //    console.log(errorThrown);
            }


        });




    });

    /**TRACKING/SEGUIMIENTO DE ENVIO */

    $(document).on('click', '#trakingEnvio', function() {

        let ordenTransporte = $(this).data('ot');
        let cuenta = $(this).data('cuenta');
        let entorno = $(this).data('entorno');
        let windOpenTraking = null;

        if (entorno == 'PRE') {

            windOpenTraking = window.open("https://gtstntpre.alertran.net/gts/pub/clielocserv.seam?expedicion=" + ordenTransporte + "&cliente=" + cuenta + ", _blank");
        } else {

            windOpenTraking = window.open("https://gtstnt.tntchile.cl/gtstnt/pub/clielocserv.seam?expedicion=" + ordenTransporte + "&cliente=" + cuenta + ", _blank");
        }
        if (windOpenTraking) {
            //Browser has allowed it to be opened
            win.focus();
        } else {
            //Browser has blocked it
            alert('Permita las ventanas emergentes para este sitio');
        }


    });





    $(document).on('click', '#detalle', function(event) {
        event.preventDefault();

        numberOrder = $(this).data('order');
        customerid = $(this).data('customerid');
        console.log("Detalle"+numberOrder);


        let url = fdx_script_obj.urlPedido;

        $.ajax({
            type: "POST",
            url: url,
            data: {
                'numberOrder': numberOrder,
                'customerid': customerid
            },
            success: function(response) {

                let obj = jQuery.parseJSON(response);
                console.warn(response);
                $('#detallePedido').modal('show');

                //console.log(obj);
                let html = '';
                let order = '';

                $.each(obj, function(key, value) {

                    console.log(value);
                    html += '<tr>' +
                        '<td>' + value.date_created + '</td>' +
                        '<td>' + value.order_item_name + '</td>' +
                        '<td>' + value.product_qty + '</td>' +
/*                         '<td>' + parseFloat(value.product_gross_revenue).toFixed(2) + '</td>' +
 */                        '</tr>';
                    order = value.order_id;
                });
                $('#showOrder').html(order);
                $('#detailOrder').html(html);

            },
            error: function(errorThrown) {
                //    console.log(errorThrown);
            }
        });

    });



});

})(jQuery);