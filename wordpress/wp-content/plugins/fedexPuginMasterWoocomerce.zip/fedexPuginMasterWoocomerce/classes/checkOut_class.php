<?php

defined('ABSPATH') || exit;

add_action('woocommerce_checkout_order_processed', 'action_checkout_order_processed', 10, 1);
function action_checkout_order_processed($order_id)
{
    // Declaración global Base de datos
    global $wpdb;
    global $table_prefix;
    // get an instance of the order object
    $order = wc_get_order($order_id);
    $order_data = $order->get_data(); // The Order data

    $table = $table_prefix . "caracteristicas_ordenes";
    $data = array(
        'ID_ORDER' => $order->get_id(),
        'PESO_ENVIO' =>  WC()->cart->cart_contents_weight,
        'VOLUMEN_ENVIO' => get_cart_volume(),
        'COSTO_ENVIO' => '',
        'created_at' =>  $order_data['date_created']->date('Y-m-d H:i:s')
    );
    //$where = array('ID_ORDER' => 9000);
    $wpdb->insert($table, $data, null);
}


function get_cart_volume(){
    // Initializing variables
    $volume = $rate = 0;
    // Get the dimetion unit set in Woocommerce
    $dimension_unit = get_option( 'woocommerce_dimension_unit' );
    // Calculate the rate to be applied for volume in m3
    if ( $dimension_unit == 'mm' ) {
        $rate = pow(10, 9);
    } elseif ( $dimension_unit == 'cm' ) {
        $rate = pow(10, 6);
    } elseif ( $dimension_unit == 'm' ) {
        $rate = 1;
    }
    if( $rate == 0 ) return false; // Exit
    // Loop through cart items
    foreach(WC()->cart->get_cart() as $cart_item) { 
        // Get an instance of the WC_Product object and cart quantity
        $product = $cart_item['data'];
        $qty     = $cart_item['quantity'];
        // Get product dimensions  
        $length = $product->get_length();
        $width  = $product->get_width();
        $height = $product->get_height();
        // Calculations a item level
        $volume += $length * $width * $height * $qty;
    }
    
   // return $volume / $rate;

    $volumenRate = $volume/$rate;
    if( $volumenRate <= '0.01' || $volumenRate <= 0.01 ){
        return 0.01;
    }else{
        return $volumenRate;
    }




}