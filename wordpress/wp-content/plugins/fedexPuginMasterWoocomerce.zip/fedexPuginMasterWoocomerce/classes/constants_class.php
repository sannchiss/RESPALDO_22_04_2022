<?php

class constant{

    //Define module Constants
    const KEY = 'JF#RF3N8eZ_uKb24_K{M';
    const PASSWORD = 'Fedex.4322';    


}