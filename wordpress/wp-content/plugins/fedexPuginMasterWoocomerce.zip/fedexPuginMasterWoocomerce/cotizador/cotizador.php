<?php

if (!defined('ABSPATH')) {
    die();
}

/**
 * Add html
 *
 * @version 1.0.0
 * @since   1.0.0
 */
add_action( 'woocommerce_after_checkout_billing_form', 'add_box_option_to_checkout' );
function add_box_option_to_checkout( $checkout ) {
	echo '<div id="message_fields">';
	woocommerce_form_field( 'add_gift_box', array(
		'type'          => 'checkbox',
		'class'         => array('add_gift_box form-row-wide'),

		'label'         => esc_html__( 'Envía con FedEx', '@@pkg.textdomain' ),
		'placeholder'   => '',
	), $checkout->get_value( 'add_gift_box' ));
	echo '</div>';
}

/**
 * Add Javascript
 *
 * @version 1.0.0
 * @since   1.0.0
 */
add_action( 'wp_footer', 'woocommerce_add_gift_box' );

function woocommerce_add_gift_box() {
	if (is_checkout()) {
		?>
		<script type="text/javascript">
			jQuery( document ).ready(function( $ ) {
				$('#add_gift_box').click(function(){
					jQuery('body').trigger('update_checkout');


				});



			});
		</script>
		<?php
	}
}

/**
 * Add fee to cart
 *
 * @link    https://docs.woocommerce.com/document/add-a-surcharge-to-cart-and-checkout-uses-fees-api/
 * @version 1.0.0
 * @since   1.0.0
 */
add_action( 'woocommerce_cart_calculate_fees', 'woo_add_cart_fee' );
function woo_add_cart_fee( $cart ){
	if ( ! $_POST || ( is_admin() && ! is_ajax() ) ) {
		return;
	}

    
	if ( isset( $_POST['post_data'] ) ) {
         
        global $woocomerce;
        
        

		parse_str( $_POST['post_data'], $post_data );



        //print_r(WC()->cart);

        $costoEnvio = $post_data['billing_postcode'];


	} else {
		$post_data = $_POST;
	}

	if (isset($post_data['add_gift_box'])) {
		$extracost = 1;
		WC()->cart->add_fee( esc_html__( 'Envío con FedEx:', '@@pkg.textdomain' ), $costoEnvio );
	}

}

   global $wpdb;


add_filter( 'woocommerce_default_address_fields' , 'set_custom_company_checkout_field' );
function set_custom_company_checkout_field( $address_fields ) {

    // Unset company field type
    unset($fields['company']['type']);

    global $wpdb;
    $select_options = array();

    // @@@ you will need to replace names table and columns and adapt this !!!
    $query = "SELECT id, NUMERO_ENVIO FROM plugin_envios_ecommerce";
    $requestAll  = $wpdb->get_results($query);

    // Storing object $company_name keys/values in $select_options array
    foreach ( $requestAll as $request ) 
    {
        $key = 'option_'. $request->id;
        $value = $request->NUMERO_ENVIO;
        $select_options[$key] = $value ;
    }

    $address_fields['company']['type'] = 'select';
    $address_fields['company']['options'] = $select_options;
    // (optional) 
    // $address_fields['company']['default'] = $select_options['option_1'];

    return $address_fields;
}
