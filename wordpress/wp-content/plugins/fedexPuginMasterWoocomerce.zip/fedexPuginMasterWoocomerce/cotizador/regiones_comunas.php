<?php

// Add checkout custom select fields
add_action( 'woocommerce_before_order_notes', 'add_checkout_custom_fields', 20, 1 );
function add_checkout_custom_fields( $checkout) {
    $domain = 'woocommerce'; // The domain slug

    echo '<h2>'.__( 'Next Day Delivery', $domain ).'</h2>';

    // First Select field (Master)
    woocommerce_form_field( 'delivery_one', array(
        'type'          => 'select',
        'label'         => __( 'Delivery options one' , $domain),
        'class'         => array( 'form-row-wide' ),
        'required'       => true,
        'options'       => array(
            ''  => __( 'Selecciona la Región', $domain ),
            'A' => __( 'A', $domain ),
            'B' => __( 'B', $domain ),
            'C' => __( 'C', $domain ),
        ),
    ),
    $checkout->get_value( 'delivery_one' ) );

    // Default option value
    $default_option2 = __( 'Please select a value', $domain );

    // Dynamic select field options for Javascript/jQuery
    $options_0 = array( '' => $default_option2 );
    $options_a = array(
        ''  => $default_option2,
        'D' => __( 'D', $domain ),
        'E' => __( 'E', $domain ),
        'F' => __( 'F', $domain ),
        'G' => __( 'G', $domain ),
    );
    $options_b = array(
        ''  => $default_option2,
        'H' => __( 'H', $domain ),
        'I' => __( 'I', $domain ),
        'J' => __( 'J', $domain ),
    );
    $options_c = array(
        ''  => $default_option2,
        'K' => __( 'K', $domain ),
        'L' => __( 'L', $domain ),
        'M' => __( 'M', $domain ),
    );

    // Second Select field (Dynamic Slave)
    woocommerce_form_field( 'delivery_two', array(
        'type'          => 'select',
        'label'         => __( 'Delivery options two', $domain ),
        'class'         => array( 'form-row-wide' ),
        'required'       => true,
        'options'       => $options_0,
    ),
    $checkout->get_value( 'delivery_two' ) );

    $required = esc_attr__( 'required', 'woocommerce' );

    // jQuery code
    ?>
    <script>
    jQuery(function($){
        var op0 = <?php echo json_encode($options_0); ?>,
            opa = <?php echo json_encode($options_a); ?>,
            opb = <?php echo json_encode($options_b); ?>,
            opc = <?php echo json_encode($options_c); ?>,
            select1 = 'select[name="delivery_one"]',
            select2 = 'select[name="delivery_two"]';

        // Utility function to fill dynamically the select field options
        function dynamicSelectOptions( opt ){
            var options = '';
            $.each( opt, function( key, value ){
                options += '<option value="'+key+'">'+value+'</option>';
            });
            $(select2).html(options);
        }

        // 1. When dom is loaded we add the select field option for "A" value
        // => Disabled (optional) — Uncomment below to enable
        // dynamicSelectOptions( opa );

        // 2. On live selection event on the first dropdown
        $(select1).change(function(){
            if( $(this).val() == 'A' )
                dynamicSelectOptions( opa );
            else if( $(this).val() == 'B' )
                dynamicSelectOptions( opb );
            else if( $(this).val() == 'C' )
                dynamicSelectOptions( opc );
            else
                dynamicSelectOptions( op0 ); // Reset to default
        });
    });
    </script>
    <?php
}

// Check checkout custom fields
add_action( 'woocommerce_checkout_process', 'wps_check_checkout_custom_fields', 20 ) ;
function wps_check_checkout_custom_fields() {
    // if custom fields are empty stop checkout process displaying an error notice.
    if ( empty($_POST['delivery_one']) || empty($_POST['delivery_two']) ){
        $notice = __( 'Please select a day part under Delivery options' );
        wc_add_notice( '<strong>' . $notice . '</strong>', 'error' );
    }
}

