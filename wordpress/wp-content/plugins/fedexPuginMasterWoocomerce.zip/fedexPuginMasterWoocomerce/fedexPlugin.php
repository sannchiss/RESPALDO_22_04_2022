<?php

/**
 * Plugin Name: FedEx Envios Chile
 * Plugin URI: https://gtstnt.tntchile.cl/gtstnt/login.seam
 * Description: FedEx Envios Chile
 * Version: 1.0
 * Author: Sannchiss Pérez
 * Author URI: https://gtstnt.tntchile.cl/gtstnt/login.seam
 * Text Domain: FedexPlugin
 * Domain Path: /lenguages
 * Licence: GPL2
 * 
 * Plugin de Software libre
 *
 * @package FedexPlugin
 */
/**
 * Returns the main instance of WC.
 *
 * @since  1.0
 * @return FedexPlugin
 */

defined('ABSPATH') || exit;

//Constante de la ruta del plugin de nombre: PLUGIN_DIR_PATH
define('PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));


class fedexPlugin
{


    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;

        $this->includesFDX();
        $this->activationHookFDX();


    }


    public function includesFDX()
    {
        require_once PLUGIN_DIR_PATH . 'lib/initCreateTable.php';

        #Requerimos el archivo Helpers las funciones para llamar al menú en su contrucción
        require_once PLUGIN_DIR_PATH . 'lib/helpersfx.php';

        require_once PLUGIN_DIR_PATH . 'classes/checkOut_class.php';

        //require_once PLUGIN_DIR_PATH . 'cotizador/regiones_comunas.php';
    }

    public function activationHookFDX()
    {

        /**************************************************************************** */
        //Uso en creación de tablas si no existen

        $initCreateTable = new tablaInit();
        // Cuando el plugin se active se crea la tabla del mismo si no existe
        register_activation_hook(__FILE__, array($initCreateTable, 'tableSend'));
        register_activation_hook(__FILE__, array($initCreateTable, 'characteristicOrder'));
        register_activation_hook(__FILE__, array($initCreateTable, 'configuration'));
        register_activation_hook(__FILE__, array($initCreateTable, 'cityOrComune'));
        register_activation_hook(__FILE__, array($initCreateTable, 'confirmation'));
        

        add_action('admin_menu', array($this, 'fp_options_page'), 8);
        add_action('init', array($this, 'registro_posventa_estado_pedido'));

        add_action('admin_enqueue_scripts', array($this, 'load_script'));
        add_action('admin_enqueue_scripts', array($this, 'load_style'));


        add_action('wp_enqueue_scripts', array($this, 'cotizador'));

        add_action('wp_ajax_loadPrice', array($this, 'loadPrice' ));

        



        //Elimina Tabla descripción detalle compra CheckOut
        //add_action( 'after_setup_theme', array($this,  'fedex_custom_checkout_woocommmerce' ));


        add_filter('wc_order_statuses', array($this, 'anadir_posventa_lista'));

        /*************************************************************************** */
 
    }



    /* if (file_exists($whq_wcchp_default['plugin_path'] . 'cotizador/cotizador.php')) {
    include_once $whq_wcchp_default['plugin_path'] . 'cotizador/cotizador.php';
}
 */



    //Añadir campo

    /* add_action('woocommerce_checkout_order_review', 'insert_row_fedex');

function insert_row_fedex(){



} */

    public  function fp_options_page()
    {


        $menus = [];

        $menus[] = [
            'pageTitle' => 'FedEx Chile',
            'menuTitle' => 'E-commerce',
            'capability' => 'manage_options',
            'menuSlug' =>   'FX_MENU',
            'menu_slug'  =>  plugin_dir_path(__FILE__) . 'view/pedidosInicio.php',  //Ruta absoluta
            'functionName' => null, //LLama a la función
            'iconUrl' => plugin_dir_url(__FILE__) . 'admin/images/Fedex-GroundIconWP.png',  //Ruta absoluta
            'position' => 19
        ];

        addMenusPanel($menus);

        $submenu = [];

        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Gestión de envios',
            'menu_title'  => 'Gestión de envios',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/pedidosInicio.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];


        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Envios confirmados',
            'menu_title'  => 'Envios confirmados',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/enviosConfirmados.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];


        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Retiros confirmados',
            'menu_title'  => 'Retiros confirmados',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/confirmacion.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];

        $submenu[] = [
            'parent_slug' => 'FX_MENU', // Slug Padre
            'page_title'  => 'Configuración',
            'menu_title'  => 'Configuración',
            'capabality'  => 'manage_options',
            'menu_slug'   =>  plugin_dir_path(__FILE__) . 'view/configuracion.php',  //Ruta absoluta
            'functionName' => '' //Lamado a la funcion
        ];

        addSubMenusPanel($submenu);

    }




    function load_script()
    {

/*         
ADD WITH CDN
wp_enqueue_script( 'bootstrapjs', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js', array('jquery'), '', true );

 */

        wp_enqueue_script(
            'load_component',
            plugins_url('admin/js/librerias/loadComponents.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );

        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
        wp_localize_script(
            'load_component',
            'load_obj',
            array(

                'urlLoadConfig'   => plugins_url('router.php?URI=cargaConfiguracion', __FILE__),
                'urlLoadPrint'    => plugins_url('router.php?URI=cargarImpresora', __FILE__)
            )
        );

        /********************************************************************************************************************** */

        wp_enqueue_script(
            'fdx_script',
            plugins_url('admin/js/acciones.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );


        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
        wp_localize_script(
            'fdx_script',
            'fdx_script_obj',
            array(

                'urlPedido'         => plugins_url('router.php?URI=detallePedido', __FILE__),
                'urlConfig'         => plugins_url('router.php?URI=configuracion', __FILE__),
                'urlCrearEnvio'     => plugins_url('router.php?URI=cargarEnvioForm', __FILE__),
                'urlCompLocation'   => plugins_url('router.php?URI=autoCompletLocation', __FILE__),
                'urlInsertBD'       => plugins_url('router.php?URI=insertEnvioBD', __FILE__)

            )
        );

        /********************************************************************************************************************** */

        wp_enqueue_script(
            'call_services',
            plugins_url('admin/js/callService.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );


        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
        wp_localize_script(
            'call_services',
            'call_services_obj',
            array(
                'urlDocEnvio'   => plugins_url('router.php?URI=crearEnvioWS', __FILE__),
                'urlImpresion'  => plugins_url('router.php?URI=imprimirEnvioWS', __FILE__),
                'urlEntrega'    => plugins_url('router.php?URI=entregaEnvioWS', __FILE__)
            )
        );

        /********************************************************************************************************************** */

        wp_enqueue_script(
            'loadDataTable',
            plugins_url('admin/js/loadDataTable.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );

        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
        wp_localize_script(
            'loadDataTable',
            'load_data_obj',
            array(
                'urlLoadPedidos'    => plugins_url('router.php?URI=cargarPedidos', __FILE__),
                'urlRecogida'       => plugins_url('router.php?URI=listarRecogidasWS', __FILE__),
                'urlImpRecogida'    => plugins_url('router.php?URI=imprimirRecogidaWS', __FILE__),
                'urlEnvConfir'      => plugins_url('router.php?URI=enviosConfirmadosWS', __FILE__),
                'urlImpMasivo'      => plugins_url('router.php?URI=impresionMasivaWS', __FILE__),
                'urlEliminar'       => plugins_url('router.php?URI=eliminarEnvioWS', __FILE__),
                'urlTest'           => plugins_url('router.php?URI=TestExtends', __FILE__)



            )
        );
    }

    function load_style(){


/*
ADD WITH CDN
wp_enqueue_style( 'bootstrap-select', 'http://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.3/css/bootstrap-select.min.css');

 */

    }

    //Remover tabla detalle de pedido del CheckOut
    function fedex_custom_checkout_woocommmerce() {
 	
        //remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
        remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
    
        //Acción para remover el total y subtotal de la compra
       // remove_action( 'woocommerce_checkout_order_review', 'woocommerce_order_review', 10 );
        //remove_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 );
         
    }



    //Añadir nuevo estado.

    //Registro del nuevo estado
    function registro_posventa_estado_pedido()
    {
        register_post_status('wc-fedex', array(
            'label'                     => 'Enviado-Fedex', //Nombre público
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Enviado-Fedex (%s)', 'Enviado-Fedex (%s)')
        ));
    }

    //Añade estado 'Fedex' al lisatdo disponible de Woocomerce wc_order_statuses
    function anadir_posventa_lista($order_statuses)
    {
        $new_order_statuses = array();
        // lo ponemos despues de Completado
        foreach ($order_statuses as $key => $status) {
            $new_order_statuses[$key] = $status;
            if ('wc-completed' === $key) {
                $new_order_statuses['wc-fedex'] = 'Enviado-Fedex';
            }
        }
        return $new_order_statuses;
    }




// Agrego el archivo scripts.js a wordpress
function cotizador()
{

        wp_enqueue_script(
            'cotizador',
            plugins_url('admin/js/cotizador.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );


        // El wp_localize_script nos permite generar la ruta ajax_url para que la use nuestro script.
        wp_localize_script(
            'cotizador',
            'cotizador_obj',   
            array(  
                 'ajax_url' => admin_url( 'admin-ajax.php' ) 
            )
        );


    //Mediante wp_localize_script le mando un array con el resultado de las funciones que necesite

		/* wp_localize_script('cotizador', 'my-scripts', array(
                'tipos'=> 'tipos_list()',
                'categoriesList'=> 'categories_list()',
		)
		); */
}






}


/*Instantiate class*/

    $GLOBALS['fedexPlugin'] = new fedexPlugin();
