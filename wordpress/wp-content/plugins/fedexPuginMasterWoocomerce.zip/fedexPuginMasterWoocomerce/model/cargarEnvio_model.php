<?php

class FDX_cargar
{

    use configurationAccount;

    public function __construct()
    {
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }


    public function cargarEnvio($numberOrder)
    {

        $request = new FDX_cargar();

        $configuracion = $request->return_config();

        $bultoPedido = $configuracion['BULTO_POR_PEDIDO'];


        //Consulta por datos en tabla caracteristicas de Orden: Kilos, Volumen, Costo
        $detalleOrden = $this->wpdb->get_results("SELECT * FROM ". $this->table_prefix ."caracteristicas_ordenes WHERE ID_ORDER=$numberOrder", ARRAY_A );

        $confBulto = array(
            
            "bultoPedido" => $bultoPedido
        );

        $postmeta = get_post_meta($numberOrder);
        $post =     get_post($numberOrder);


        $altDetalle = array();
        if(empty($detalleOrden)) {
            //Orden no existe
            $altDetalle = array(
                "mensaje" => "la orden no esta en la tabla"
            );    
        } else {
            $altDetalle = $detalleOrden[0];
            }

        
        //Convierto el Objeto de Post en Array y poder usar asi array_merge para concatenar 
        //las dos $postmeta y $post en un solo Json $listajson
        $array_post =  (array) $post;
        $listajson =  json_encode(array_merge($postmeta, $array_post, $confBulto, $altDetalle));
        return  $listajson;
    }
}
