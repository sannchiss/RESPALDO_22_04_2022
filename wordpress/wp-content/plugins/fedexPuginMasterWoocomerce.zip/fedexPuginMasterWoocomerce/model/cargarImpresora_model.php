<?php

class listaImpresoras_FDX{

    use configurationAccount;
    use encriptacion;

    public function __construct()
    {
        
    }

    public function cargarImpresora($puerto){

        $request = new listaImpresoras_FDX();
        $instanciaKey =  new constant();



        $configuracion = $request->return_config();

        $username =  $configuracion['USUARIO'];
        $password =  $configuracion['CONTRASENA'];

        //Desencriptar password
        $passwordDecode =  $request->desencriptar( $password[0], $instanciaKey::KEY );

        $options = array('auth' => array($username[0], $passwordDecode));



        if( $puerto == '62341' ){

            $url = 'https://impresion.alertran.net:62341/printService/listprinters';

        }else{

            $url = 'http://impresion.alertran.net:62342/printService/listprinters';

        }

      
        $headers = array('Accept' => 'application/json', 
                        'Content-Type' => 'application/json');

        $ws_response = RestClientFDX::GET($url, $headers, null, $options);

        $response_json = json_encode($ws_response->body, true);
            
        echo json_decode($response_json, true);  


    }
}