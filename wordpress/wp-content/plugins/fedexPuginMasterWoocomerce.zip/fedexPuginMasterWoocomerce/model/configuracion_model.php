<?php

class FDX_configuracion{

    use encriptacion;

    public function __construct()
    {
        global $wpdb;
        global $table_prefix;
    
        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
        
    }


    public function configuracion( $cuenta_cliente, $usuario, $contrasena, $tipo_entorno, $tipo_impresion, $impresora, $select_bultos ){
       
        $instanciaKey =  new constant();

        var_dump( $impresora ); 
       
        $response = new FDX_configuracion();
        $table = $this->table_prefix . "configuracion_fedex";
        $data = array(
            'cuentaGTS'         => $cuenta_cliente,
            'usuario'           => $usuario,
            'contrasena'        => $contrasena,
            'ENTORNO'           => $tipo_entorno,
            'TIPO_ETIQUETAS'    => $tipo_impresion,
            'NOMBRE_IMPRESORA'  => $impresora,
            'BULTO_POR_PEDIDO'  => $select_bultos
        );


        $where = array( 'id' => 1 );
        $this->wpdb->update($table, $data, $where);

        return "Inserción realizada con exito";


    }




}