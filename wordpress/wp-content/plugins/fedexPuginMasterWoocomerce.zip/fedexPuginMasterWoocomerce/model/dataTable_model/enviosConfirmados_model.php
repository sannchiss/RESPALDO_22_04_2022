<?php

class enviosConfirmados_FDX{

    use configurationAccount;


public function __construct()
{
    global $wpdb;
    global $table_prefix;

    $this->wpdb = $wpdb;
    $this->table_prefix = $table_prefix;
    
}

public function enviosGestionados(){

    $request = new enviosConfirmados_FDX();

    $configuracion = $request->return_config();

    $cliente_centro =   $configuracion['CUENTA_GTS'];
    $entorno =          $configuracion['ENTORNO'];


    $table = $this->table_prefix . "envios_ecommerce";

    $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT * FROM $table WHERE RECOGIDA=%s", 1));


    $updateEnvios = array();


    foreach ($results as $key => $value) {
        # code...

        $updateEnvios[$key] = array( 

            "id" =>               [$value->id],
            "ID_ORDER"=>          [$value->ID_ORDER],
            "NUMERO_ENVIO"=>      [$value->NUMERO_ENVIO],
            "created_at"=>        [$value->created_at],
            "RESPUESTA_SERV"=>    [$value->RESPUESTA_SERV],
            "CLIENTE_CENTRO"=>    [$cliente_centro[0]],
            "ENTORNO" =>          [$entorno[0]]

    );



}


echo json_encode( $updateEnvios );


}

}