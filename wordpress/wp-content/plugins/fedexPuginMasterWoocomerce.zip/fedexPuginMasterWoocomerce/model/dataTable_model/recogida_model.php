<?php

class recogida_FDX
{

    public function __construct()
    {

        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }

    public function recogida()
    {

        $tableRecogida = $this->table_prefix . "confirmation_retiros";

        $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT id,created_at,ID_RECOGIDA,MANIFIESTO_64Bytes
        FROM $tableRecogida GROUP BY ID_RECOGIDA ORDER BY created_at ASC ", ARRAY_A));


        $listconRecogidas[] = null;
        if (sizeof($results) == 0) {
            //error_log('No se ha obtenido la configuracion');
            return $listconRecogidas;
        }

        foreach ($results as $key => $value) {  
            # code...

            $listconRecogidas = array(
                "id"                    => [$value->id],
                "created_at"            => [$value->created_at],
                "ID_RECOGIDA"           => [$value->ID_RECOGIDA],
                "MANIFIESTO_64Bytes"    => [$value->MANIFIESTO_64Bytes],
            );


            // $configuracion[$result->clave] = $result->valor;
        }



        echo json_encode($results);
    }
}
