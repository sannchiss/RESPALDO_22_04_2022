<?php

class FDX_detallePedido{


public function __construct(){
    
    global $wpdb;
    global $table_prefix;

    $this->wpdb = $wpdb;
    $this->table_prefix = $table_prefix;
    
}


public function detalle($numberOrder, $customerid){

    $listaPedido = $this->wpdb->get_results(" SELECT " . $this->table_prefix . "wc_order_product_lookup.order_id," . $this->table_prefix . "wc_order_product_lookup.date_created, 
    " . $this->table_prefix . "woocommerce_order_items.order_item_name, " . $this->table_prefix ."wc_order_product_lookup.product_qty," . $this->table_prefix . "wc_order_product_lookup.product_gross_revenue FROM " . $this->table_prefix . "wc_order_product_lookup
    INNER JOIN " . $this->table_prefix . "woocommerce_order_items ON 
    " . $this->table_prefix . "wc_order_product_lookup.order_item_id  = " . $this->table_prefix . "woocommerce_order_items.order_item_id 
    WHERE " . $this->table_prefix . "wc_order_product_lookup.order_id = $numberOrder
    GROUP BY " . $this->table_prefix . "woocommerce_order_items.order_item_name ORDER BY " . $this->table_prefix . "woocommerce_order_items.order_item_name
    ASC", ARRAY_A );

    $listajson = json_encode( $listaPedido );

    return  $listajson;



}


    
}


