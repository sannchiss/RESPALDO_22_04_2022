<?php

if (!defined('ABSPATH')) {
    die();
}



class FDX_gestion
{


    public function __construct()
    {

        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }



    public function mostrarEnvio($date_start, $date_end)
    {

        // Obteniendo la fecha actual con hora, minutos y segundos en PHP
        $fechaActual = date('Y-m-d H:i:s');

        //resto los dias para mostrar pedidos en un plazo
        $fechaInicio  =  date("Y-m-d H:i:s", strtotime($fechaActual . " -50 days"));

        $incioBuscar =  empty($date_start)  ?  $fechaInicio : $date_start;
        $finBuscar =    empty($date_end)  ? $fechaActual : $date_end;



        //  var_dump($incioBuscar."/".$finBuscar);


    $list = $this->wpdb->get_results("SELECT " . $this->table_prefix . "wc_order_stats.order_id, CONCAT( " .
            $this->table_prefix . "wc_customer_lookup.first_name, ' ', " . $this->table_prefix . "wc_customer_lookup.last_name) AS nombre , 
    " . $this->table_prefix . "wc_order_stats.date_created,  " . $this->table_prefix . "wc_order_stats.num_items_sold , " .
            $this->table_prefix . "wc_customer_lookup.city, " . $this->table_prefix . "wc_customer_lookup.state , " .
            $this->table_prefix . "wc_order_stats.customer_id , " .
            $this->table_prefix . "envios_ecommerce.RESPUESTA_SERV , " .
            $this->table_prefix . "envios_ecommerce.NUMERO_ENVIO , " .
            $this->table_prefix . "envios_ecommerce.ESTADO_ETIQUETA , " .
            $this->table_prefix . "envios_ecommerce.RECOGIDA FROM " . $this->table_prefix . "wc_order_stats 
    INNER JOIN " . $this->table_prefix . "wc_customer_lookup ON 
    " . $this->table_prefix . "wc_order_stats.customer_id =  " . $this->table_prefix . "wc_customer_lookup.customer_id 
    INNER JOIN  " . $this->table_prefix . "woocommerce_order_items ON 
    " . $this->table_prefix . "wc_order_stats.order_id =  " . $this->table_prefix . "woocommerce_order_items.order_id
   
    INNER JOIN  " . $this->table_prefix . "posts ON 
    " . $this->table_prefix . "wc_order_stats.order_id =  " . $this->table_prefix . "posts.ID
    
    LEFT JOIN  " . $this->table_prefix . "envios_ecommerce ON 
    " . $this->table_prefix . "wc_order_stats.order_id =  " . $this->table_prefix . "envios_ecommerce.ID_ORDER           
    WHERE  (" . $this->table_prefix . "posts.post_status = 'wc-processing' OR " . $this->table_prefix . "posts.post_status = 'wc-on-hold' OR " . $this->table_prefix . "posts.post_status = 'wc-completed'
     )
      GROUP BY  " . $this->table_prefix . "wc_order_stats.order_id ORDER BY  " . $this->table_prefix . "wc_order_stats.order_id DESC");


        echo json_encode($list);
    }
}
