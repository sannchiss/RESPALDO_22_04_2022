<?php

class autoCompleteLocation_FDX{


public function __construct()
{
    
    global $wpdb;
    global $table_prefix;

    $this->wpdb = $wpdb;
    $this->table_prefix = $table_prefix;

}

public function loadLocations(){

    
    $query = $this->wpdb->get_results($this->wpdb->prepare("SELECT * FROM " . $this->table_prefix. "localidades"));

    $listajson = json_encode( $query );

    return  $listajson;
    

}




}