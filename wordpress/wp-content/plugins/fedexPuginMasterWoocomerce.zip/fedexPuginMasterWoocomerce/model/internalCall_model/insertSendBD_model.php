<?php

class insertSend_FDX
{


  public function __construct()
  {
    global $wpdb;
    global $table_prefix;

    $this->wpdb = $wpdb;
    $this->table_prefix = $table_prefix;
  }

  public function insertSendBD($request)
  {

    $nombreTabla = $this->wpdb->prefix  . 'envios_ecommerce';
    $date = date("Y-m-d H:i:s");

    foreach ($request as $key => $value) {

      var_dump($value);

      $this->wpdb->insert(
        $nombreTabla,
        array(
          'ID_ORDER' =>         $value["order"],
          'NUMERO_ENVIO' =>     $value["numero_envio"],
          'ESTADO_ETIQUETA' =>  $value["impresionEtq"],
          'RESPUESTA_SERV' =>   $value["mensaje"],
          'RECOGIDA' =>         $value["solicitudRecogida"],
          'ETIQUETA_64Bytes' => $value["etiqueta"],
          'created_at' =>       $date
        )
      );
    }
    
  }
}
