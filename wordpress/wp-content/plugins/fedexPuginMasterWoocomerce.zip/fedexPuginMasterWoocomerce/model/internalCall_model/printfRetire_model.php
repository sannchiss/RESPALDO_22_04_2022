<?php

class printfRetiro_FDX{

public function __construct()
{
    global $wpdb;
    global $table_prefix;

    $this->wpdb = $wpdb;
    $this->table_prefix = $table_prefix;

}


public function printfRetiro( $retiro ){

    $table = $this->table_prefix . "confirmation_retiros";

    $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT * FROM $table WHERE ID_RECOGIDA ='%s'", $retiro));
 
    echo json_encode( $results, true );

}




}