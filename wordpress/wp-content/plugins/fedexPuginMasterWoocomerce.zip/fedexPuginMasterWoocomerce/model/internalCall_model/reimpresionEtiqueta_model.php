<?php


class reimpresionEtiqueta_FDX{

    use configurationAccount;


    public function __construct()
    {
        
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;

    }


    public function reimpresionEtiqueta( $ordenTransporte ){

    $request = new reimpresionEtiqueta_FDX();

    $configuracion = $request->return_config();

    $nombre_impresora = $configuracion['NOMBRE_IMPRESORA'];

    $tipo_etiqueta =   $configuracion['TIPO_ETIQUETAS'];

    $table = $this->table_prefix . "envios_ecommerce";

    $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT * FROM $table WHERE NUMERO_ENVIO ='%s'", $ordenTransporte));


     $updateEnvios = array();


    foreach ($results as $key => $value) {
        # code...

        $updateEnvios[$key] = array( 

            "id" =>                [$value->id],
            "ID_ORDER"=>           [$value->ID_ORDER],
            "NUMERO_ENVIO"=>       [$value->NUMERO_ENVIO],
            "created_at"=>         [$value->created_at],
            "RESPUESTA_SERV"=>     [$value->RESPUESTA_SERV],
            "ETIQUETA_64Bytes"=>   [$value->ETIQUETA_64Bytes],
            "NOMBRE_IMPRESORA" =>  [$nombre_impresora[0]],
            "TIPO_ETIQUETAS" =>    [$tipo_etiqueta[0]]

    );
        # code...
    }     



    echo json_encode( $updateEnvios, true );





    }




}