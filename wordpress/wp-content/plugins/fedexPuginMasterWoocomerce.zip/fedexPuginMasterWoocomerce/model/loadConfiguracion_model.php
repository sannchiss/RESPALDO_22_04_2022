<?php


class loadConfiguracion_FDX
{

    public function __construct()
    {

        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }

    public function loadConfiguracion()
    {


        $table = $this->table_prefix . "configuracion_fedex";

        $where = array(
            'id' => 1
        );

        $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT * FROM $table WHERE id = 1", null));

        echo json_encode($results);
    }
}
