<?php


class borraEnvio_FDX
{

    use configurationAccount;
    use encriptacion;


    public function __construct()
    {
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }

    public function borrarEnvio( $Ot, $passDeco )
    {

        $request = new borraEnvio_FDX();

        $instanciaKey =  new constant();

        $configuracion =  $request->return_config();

        $cliente_centro =   $configuracion['CUENTA_GTS'];
        $username =         $configuracion['USUARIO'];
        $password =         $configuracion['CONTRASENA'];
        $entorno =          $configuracion['ENTORNO'];
        $ws_url_pre =       $configuracion['WS_URL_PRE'];
        $ws_url_pro =       $configuracion['WS_URL_PRO'];


        /***************************************************************************** */

        /**Condicional Ambiente donde se va ejecutar el consumo del WS Documentar Envio */
        $url_base = $entorno[0] == 'PRE' ? $url_base = $ws_url_pre[0] : $ws_url_pro[0];


        $url = $url_base . '/anularWebExpediciones/anular';

        /***************************************************************************** */

        $headers = array(
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        );

        $options = array('auth' => array($username[0], $passDeco ));

        /***************************************************************************** */

        $params = '{
            "webExpediciones": {
            "numeroWebExpedicion": "'.$Ot.'",
            "clienteOrigen":"'.$cliente_centro[0].'"
                            }  
            }';


            $tablaEnvio = $this->table_prefix . "envios_ecommerce";
            $borrarEnvio = $this->wpdb->prepare("DELETE FROM $tablaEnvio WHERE NUMERO_ENVIO=%s", $Ot);
            $this->wpdb->query($borrarEnvio);

            $ws_response = RestClientFDX::post($url, $headers, $params, $options);

            $response_json = json_encode($ws_response->body, true);
        
            echo json_decode($response_json, true);


    }


}
