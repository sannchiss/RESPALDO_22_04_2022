<?php

class confirmacion_FDX
{

    use configurationAccount;
    use encriptacion;


    public function __construct()
    {
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }


    public function manifiesto($ids, $passDeco)
    {

        $request = new confirmacion_FDX();
        $instanciaKey =  new constant();


        $configuracion =  $request->return_config();

        $cliente_centro =                   $configuracion['CUENTA_GTS'];
        $username =                         $configuracion['USUARIO'];
        $password =                         $configuracion['CONTRASENA'];
        $entorno =                          $configuracion['ENTORNO'];
        $ws_url_pre =                       $configuracion['WS_URL_PRE'];
        $ws_url_pro =                       $configuracion['WS_URL_PRO'];


        /**Condicional Ambiente donde se va ejecutar el consumo del WS Documentar Envio */
        $url_base = $entorno[0] == 'PRE' ? $url_base = $ws_url_pre[0] : $ws_url_pro[0];


        $url = $url_base . '/entregaRecogedorService/entregaRecogida';

        /***************************************************************************** */

        $headers = array('Accept' => 'application/json', 'Content-Type' => 'application/json');
        $options = array('auth' => array($username[0], $passDeco));

        /***************************************************************************** */

        $params = array();

        $table = $this->table_prefix . "envios_ecommerce";
        $data = array(
            'ESTADO_ETIQUETA' => 1,
            'RECOGIDA' => 1,
            'created_at' => date("Y-m-d H:i:s")
        );

     /**CAMBIO EL ESTATUS TANTO DE LA ETIQUETA COMO DE LA RECOGIDA EN LA TABLA: envios_ecommerce */       

        foreach ($ids as $key => $value) {
            # code...
            $data[$key] = array(
                'ESTADO_ETIQUETA' => 1,
                'RECOGIDA' => 1,
                'created_at' => date("Y-m-d H:i:s")
            );

            $where = array('NUMERO_ENVIO' => $value["id_order"]);
            $this->wpdb->update($table, $data[$key], $where);

        }


        foreach ($ids as $key => $value) {

         //    var_dump( $value["id_order"] );

            $params[$key] = array('ENTREGAS' => (array('ENTREGA' => array(array(

                "CLIENTE" => $cliente_centro,
                "CENTRO" => "01",
                "EXPEDICION" => $value["id_order"],
                "ENVIO_CON_RECOGIDA" => "S",
                "MANIFIESTO" => "S"

            )))));

           

            $ws_response = RestClientFDX::post($url, $headers, json_encode($params[$key]), $options);
            $response_json = json_encode($ws_response->body, true);

            $decodeResponseRetiro = json_decode($ws_response->body, true);

            $callFunc = new confirmacion_FDX();

            $tableReco = $this->table_prefix . "confirmation_retiros";

            foreach ($decodeResponseRetiro as $key => $value) {

                //Data a ingresar dependiendo o no de que exista la recogida
                $data = array(
                    'ID_RECOGIDA' =>        $value['respuestaEntregaRecogida']['recogida'],
                    'MANIFIESTO_64Bytes' => $value['respuestaEntregaRecogida']['manifiesto'],
                    'created_at' =>         date("Y-m-d H:i:s")
                );

                if($value['respuestaEntregaRecogida']['resultado']=='OK'){

                /******************************************************* */     
                /**DATA MODIFICAR ESTADO DEL PEDIDO TABLA: wc_order_stats:status y post:post_status  */    

                $tableWc = $this->table_prefix. "wc_order_stats";
                $tablePost = $this->table_prefix. "posts";
                $tableEnvios = $this->table_prefix. "envios_ecommerce";
                $update_check = $this->wpdb->prepare("UPDATE $tableWc INNER JOIN $tableEnvios ON $tableWc.order_id = $tableEnvios.ID_ORDER 
                INNER JOIN $tablePost ON $tablePost.ID = $tableEnvios.ID_ORDER SET $tableWc.status = 'wc-fedex', $tablePost.post_status = 'wc-fedex'  WHERE $tableEnvios.RECOGIDA = 1 ", null );
                $this->wpdb->query($update_check);

                }

                if ($callFunc->verificaRecogida($value['respuestaEntregaRecogida']['recogida'])) {

                    $where = array('ID_RECOGIDA' => $value['respuestaEntregaRecogida']['recogida']);
                    $updatePickup = $this->wpdb->update($tableReco, $data, $where);
                    $this->wpdb->query($updatePickup);


                } else {

                   $insertPickup = $this->wpdb->insert($tableReco, $data);
                   $this->wpdb->query($insertPickup);


                }
            }
        }

        echo json_decode($response_json, true);
    }


    public function verificaRecogida($recogida)
    {

        $bandera = false;

        $tableRecogida = $this->table_prefix . "confirmation_retiros";
        $results = $this->wpdb->get_results($this->wpdb->prepare("SELECT ID_RECOGIDA
            FROM $tableRecogida WHERE ID_RECOGIDA=%s", $recogida));

        if (sizeof($results) > 0) {

            $bandera = true;
        } else {

            $bandera = false;

        }

        return $bandera;
    }
}
