<?php

class FDX_crearEnvio
{

    use configurationAccount;
    use encriptacion;

    public function __construct()
    {
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }

    public function creacionEnvio($requestDocSend, $passDeco)
    {

        $request = new FDX_crearEnvio();

        $instanciaKey =  new constant();

        $order = wc_get_order($requestDocSend[0]["value"]);

        $configuracion =  $request->return_config();

        $entorno =            $configuracion['ENTORNO'][0];
        $bulto_pedido =       $configuracion['BULTO_POR_PEDIDO'][0];
        $ws_url_pre =         $configuracion['WS_URL_PRE'][0];
        $ws_url_pro =         $configuracion['WS_URL_PRO'][0];

        //Credential
        $accountNumber = $configuracion['CUENTA_GTS'][0];
        $wskeyUserCredential = $configuracion['USUARIO'][0];
        //Address
        $city = $requestDocSend[5]["value"];
        $postalCode = $requestDocSend[6]["value"];
        $streetLine1 = $requestDocSend[7]["value"];
        //Recipient
        $vatNumber  = $requestDocSend[1]["value"];
        $personName = $requestDocSend[2]["value"];
        $setTelefono = str_replace('+', '', $order->get_billing_phone());
        $email = trim($order->get_billing_email());
        //ServicesLabelPrint
        $labelType = $configuracion['TIPO_ETIQUETAS'][0];
        $referencesShip = $order->get_id();



        //var_dump($request->desencriptar($password[0], $instanciaKey::KEY));
        //Desencriptar password
        //$passwordDecode =  $request->desencriptar($password[0], $instanciaKey::KEY);


        /**Condicional de bulto por pedido */
        $bultos = $bulto_pedido == 'Si' ? $bultos = 1 : $bultos = $requestDocSend[11]["value"];

        //Campo Kilo
        $kilos = $requestDocSend[12]["value"];
        //Campo Volumen
        $volumen = $requestDocSend[13]["value"];

        //Nota del Pedido
        $observacion = $requestDocSend[8]["value"];



        /***************************************************************************** */

        /**Condicional Ambiente donde se va ejecutar el consumo del WS Documentar Envio */
        $url_base = $entorno == 'PRE' ? $url_base = $ws_url_pre : $ws_url_pro;


        $url = $url_base . '/documentarEnvio/json';

        /***************************************************************************** */

        $headers = array(
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        );

        $options = array('auth' => array($wskeyUserCredential, $passDeco));
        /***************************************************************************** */


        $params = array('DOCUMENTAR_ENVIOS' => (array('DOCUMENTAR_ENVIO' => array(array(

            'REFERENCIA' => '',
            'NUMERO_ENVIO' => '',
            'CODIGO_ADMISION' => '345',
            'NUMERO_BULTOS' => $bultos,
            'CLIENTE_REMITENTE' => $accountNumber,
            'CENTRO_REMITENTE' => '01',
            'NIF_DESTINATARIO' => $vatNumber,
            'NOMBRE_DESTINATARIO' => $personName,
            'DIRECCION_DESTINATARIO' => $streetLine1,
            'PAIS_DESTINATARIO' => 'CL',
            'CODIGO_POSTAL_DESTINATARIO' => $postalCode,
            'POBLACION_DESTINATARIO' => $city,
            'PERSONA_CONTACTO_DESTINATARIO' => $personName,
            'TELEFONO_CONTACTO_DESTINATARIO' => $setTelefono,
            'EMAIL_DESTINATARIO' => $email,
            'CODIGO_PRODUCTO_SERVICIO' => '01',
            'KILOS' => $kilos,
            'VOLUMEN' => $volumen, //$volumen
            'CLIENTE_REFERENCIA' => $referencesShip,
            'IMPORTE_REEMBOLSO' => "",
            'IMPORTE_VALOR_DECLARADO' => '0',
            'TIPO_PORTES' => 'P',
            'OBSERVACIONES1' => $observacion,
            'OBSERVACIONES2' => '',
            'TIPO_MERCANCIA' => 'P',
            'VALOR_MERCANCIA' => '0',
            'MERCANCIA_ESPECIAL' => 'N',
            'GRANDES_SUPERFICIES' => 'N',
            'PLAZO_GARANTIZADO' => 'N',
            'LOCALIZADOR' => '',
            'NUM_PALETS' => 0,
            'FECHA_ENTREGA_APLAZADA' => '',
            'ENTREGA_APLAZADA' => 'N',
            'GESTION_DEVOLUCION_CONFORME' => 'N',
            'ENVIO_CON_RECOGIDA' => 'N',
            'IMPRIMIR_ETIQUETA' => 'S',
            'ENVIO_DEFINITIVO' => 'N',
            'TIPO_FORMATO' => $labelType

        )))));


        $ws_response = RestClientFDX::post($url, $headers, json_encode($params), $options);

        $response_json = json_encode($ws_response->body, true);

        echo json_decode($response_json, true);
    }
}
