<?php


class impresionEtiqueta_FDX
{
    use configurationAccount;
    use encriptacion;

    public function __construct()
    {
        global $wpdb;
        global $table_prefix;

        $this->wpdb = $wpdb;
        $this->table_prefix = $table_prefix;
    }

    public function imprimir($ot, $flat, $passDeco)
    {

        $request = new impresionEtiqueta_FDX();
        $configuracion =  $request->return_config();
        $instanciaKey =  new constant();


        $cliente_centro =                   $configuracion['CUENTA_GTS'];
        $username =                         $configuracion['USUARIO'];
        $password =                         $configuracion['CONTRASENA'];
        $entorno =                          $configuracion['ENTORNO'];
        $tipo_etiqueta =                    $configuracion['TIPO_ETIQUETAS'];
        $nombre_impresora =                 $configuracion['NOMBRE_IMPRESORA'];
        $bulto_pedido =                     $configuracion['BULTO_POR_PEDIDO'];
        $ws_url_pre =                       $configuracion['WS_URL_PRE'];
        $ws_url_pro =                       $configuracion['WS_URL_PRO'];

        //Desencriptar password
        //$passwordDecode =  $request->desencriptar($password[0], $instanciaKey::KEY);


        /**Condicional Ambiente donde se va ejecutar el consumo del WS Etiquetado */

        $url_base = $entorno[0] == 'PRE' ? $url_base = $ws_url_pre[0] : $ws_url_pro[0];

        $url = $url_base . '/etiquetarService/etiquetar';

        /***************************************************************************** */

        $headers = array('Accept' => 'application/json', 'Content-Type' => 'application/json');
        $options = array('auth' => array($username[0], $passDeco));

        /***************************************************************************** */

        $params = array('ETIQUETAS' => (array('ETIQUETA' => array(array(

            "CLIENTE"    => $cliente_centro[0],
            "CENTRO"     =>  "01",
            "EXPEDICION" =>  $ot,
            "BULTO"      =>  "",
            "FORMATO"    =>  $tipo_etiqueta[0],
            "POSICION"   =>  "",
            "ETIQUETAR"  => $flat

        )))));


        /**Modifico el estado de la etiqueta impresa = 1 */
        $table = $this->table_prefix . "envios_ecommerce";

        $data = array(
            'ESTADO_ETIQUETA' => 1
        );

        $where = array('NUMERO_ENVIO' => $ot);
        $this->wpdb->update($table, $data, $where);

        $ws_response = RestClientFDX::post($url, $headers, json_encode($params), $options);
        $response_json = json_encode($ws_response->body, true);

        $response_decode = json_decode($ws_response->body, true);


        $respuestaEtiqueta = array();


        foreach ($response_decode as $key => $value) {
            # code...

            $respuestaEtiqueta[$key] = array(

                "resultado"       =>  $value['respuestaEtiquetar']['resultado'],
                "expedicion"      =>  $value['respuestaEtiquetar']['expedicion'],
                "mensaje"         =>  $value['respuestaEtiquetar']['mensaje'],
                "etiqueta"        =>  $value['respuestaEtiquetar']['etiqueta'],
                "tipo_etiqueta"   =>  $tipo_etiqueta[0],
                "nombre_impresora"=>  $nombre_impresora[0]

            );
        }


        echo json_encode($respuestaEtiqueta, true);
    }
}
