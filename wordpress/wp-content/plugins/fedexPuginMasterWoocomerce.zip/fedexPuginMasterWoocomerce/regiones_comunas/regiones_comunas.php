<?php


/**
* Función para remover el campo de "Nombre de la Empresa" del formulario de checkout
*/
function claserama_edit_checkout_fields($fields){
    /* unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_state']); */

    return $fields;
}
add_filter('woocommerce_checkout_fields','claserama_edit_checkout_fields');


//* Add select field to the checkout page
add_action('woocommerce_before_order_notes', 'wps_add_select_checkout_field');
function wps_add_select_checkout_field( $checkout ) {

	echo '<h2>'.__('Next Day Delivery').'</h2>';

    echo '<label for="exampleDataList" class="form-label">Datalist example</label>
    <input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="Type to search...">
    <datalist id="datalistOptions">
      <option value="Region Metropolitana de Santiago">
      <option value="New York">
      <option value="Seattle">
      <option value="Los Angeles">
      <option value="Chicago">
    </datalist>';





}




//billing_city   billing_country   billing_state


add_action( 'wp_footer', 'loadSelect' );

function loadSelect() {
	
		?>
		<script type="text/javascript">
			jQuery( document ).ready(function( $ ) {
				
                $("#dataCombo").select2({
        closeOnSelect: false
      });
      $("#dataCombo").one('select2:open', function (e) {
        $(document.activeElement).blur()
      });
      $("#dataCombo").on('select2:close', function(e) {
        if ($(event.target).parents('.select2').length) {
          // The closing was done inside the select2 container
        } else {
          $("#dataCombo").one('select2:open', function (e) {
            $(document.activeElement).blur()
          });
        }
      });




			});
		</script>
		<?php
	
}




