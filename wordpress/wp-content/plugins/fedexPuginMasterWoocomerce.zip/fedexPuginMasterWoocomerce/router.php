<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
 
require_once 'classes/constants_class.php';
require_once 'trait/configurationTrait.php';
require_once 'trait/encriptacion.php';
require_once 'lib/RestClient.php';

require_once 'model/loadConfiguracion_model.php';
require_once 'model/cargarImpresora_model.php';

require_once 'model/gestionEnvio_model.php';
require_once 'model/cargarEnvio_model.php';
require_once 'model/services_model/createEnvio_model.php';
require_once 'model/services_model/impresionEnvio_model.php';
require_once 'model/services_model/call_confirEnvio_model.php';
require_once 'model/services_model/impresionMasiva_model.php';
require_once 'model/services_model/borrarEnvio_model.php';

require_once 'model/dataTable_model/enviosConfirmados_model.php';
require_once 'model/dataTable_model/recogida_model.php';
require_once 'model/detallePedido_model.php';
require_once 'model/configuracion_model.php';

require_once 'model/internalCall_model/printfRetire_model.php';
require_once 'model/internalCall_model/autocompleteLocation_model.php';
require_once 'model/internalCall_model/insertSendBD_model.php'; 




if(isset($_REQUEST['URI'])){


    $request =  $_REQUEST['URI'];

    switch ($request) {

        case 'cargarPedidos':

            $envios = new FDX_gestion();
            $envios->mostrarEnvio($_REQUEST['date_start'], $_REQUEST['date_end']); 


            break;

        case 'cargarImpresora':

            $impresoras = new listaImpresoras_FDX();
            $response = $impresoras->cargarImpresora($_REQUEST['puerto']);

            echo $response;
            break;

        case 'cargarEnvioForm':

            $loadOrder = new FDX_cargar();
            $response = $loadOrder->cargarEnvio($_REQUEST['numberOrder']);

            echo $response;

            break;

        case 'crearEnvioWS':

            $sendOrder = new FDX_crearEnvio();
            $response = $sendOrder->creacionEnvio($_REQUEST['inputs'], $_REQUEST['passDeco']);

            echo $response;
            break;

        case 'imprimirEnvioWS':

            $request = new impresionEtiqueta_FDX();

            $flat = isset($_REQUEST['flat']) ? $_REQUEST['flat'] : 'S';

            $response = $request->imprimir($_REQUEST['Ot'], $flat, $_REQUEST['passDeco']);

            echo $response;
            break;


        case 'eliminarEnvioWS':

            $request = new borraEnvio_FDX();
            $request->borrarEnvio($_REQUEST['Ot'], $_REQUEST['passDeco']);

            break;

        case 'entregaEnvioWS':

            $request = new confirmacion_FDX();
            $request->manifiesto($_REQUEST['ids'], $_REQUEST['passDeco']);

            break;

        case 'enviosConfirmadosWS':

            $request = new enviosConfirmados_FDX();
            $request->enviosGestionados();

            break;

        case 'listarRecogidasWS':

            $request = new recogida_FDX();
            $request->recogida();

            break;

        case 'imprimirRecogidaWS':

            $request = new printfRetiro_FDX();
            $request->printfRetiro($_REQUEST['orden']);

            break;

            /******Procesamiento llamados Interno ********/

        case 'detallePedido':

            $numberOrder = isset($_POST['numberOrder']) ? $_POST['numberOrder'] : 0;
            $customer =    isset($_POST['customerid']) ? $_POST['customerid'] : 0;

            $detalle = new FDX_detallePedido();
            $respuesta = $detalle->detalle($numberOrder, $customer);

            print_r($respuesta);

            break;

        case 'configuracion':

            $loadConfig = new FDX_configuracion();
            $response = $loadConfig->configuracion(
                $_REQUEST['cuenta_cliente'],
                $_REQUEST['usuario'],
                $_REQUEST['atobMethod'],
                $_REQUEST['tipo_entorno'],
                $_REQUEST['tipo_impresion'],
                $_REQUEST['impresora'],
                $_REQUEST['select_bultos']
            );

            echo $response;
            break;

        case 'autoCompletLocation':

            $request  = new autoCompleteLocation_FDX();
            $response = $request->loadLocations();

            echo $response;

            break;

        case 'insertEnvioBD':

            $request = new insertSend_FDX();
            $request->insertSendBD($_REQUEST['inputs']);

            break;

        case 'cargaConfiguracion':

            $request = new loadConfiguracion_FDX();
            $request->loadConfiguracion();

            break;

        case 'impresionMasivaWS':

            $request = new impresionMasiva_FDX();
            $request->impresionMasiva($_REQUEST['ids'], $_REQUEST['passDeco']);

            break;


    } //Fin de Switch 


}