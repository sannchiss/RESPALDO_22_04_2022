<?php

trait configurationAccount
{

    
    //Devolvemnos toda la configuracion de usuario
    function return_config()
    {
        global $wpdb;
        $table = $wpdb->base_prefix . 'configuracion_fedex';
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE id=1", null));

        $listconfiguration[0] = null;
        if (sizeof($results) == 0) {
            //error_log('No se ha obtenido la configuracion');
            return $listconfiguration;
        }

        foreach ($results as $key => $value) {
            
            # code...

            $listconfiguration = array(
                "CUENTA_GTS"                => [$value->cuentaGTS],
                "USUARIO"                   => [$value->usuario],
                "CONTRASENA"                => [$value->contrasena],
                "ENTORNO"                   => [$value->ENTORNO],
                "TIPO_ETIQUETAS"            => [$value->TIPO_ETIQUETAS],
                "NOMBRE_IMPRESORA"          => [$value->NOMBRE_IMPRESORA],
                "BULTO_POR_PEDIDO"          => [$value->BULTO_POR_PEDIDO],
                "WS_URL_PRE"                => [$value->WS_URL_PRE],
                "WS_URL_PRO"                => [$value->WS_URL_PRO],
                "URL_TRACKING_CUSTOMER_PRE" => [$value->URL_TRACKING_CUSTOMER_PRE],
                "URL_TRACKING_CUSTOMER_PRO" => [$value->URL_TRACKING_CUSTOMER_PRO],
                "URL_TRACKING_ADMINR_PRE"   => [$value->URL_TRACKING_ADMINR_PRE],
                "URL_TRACKING_ADMINR_PRO"   => [$value->URL_TRACKING_ADMINR_PRO]
            );


        }



        return $listconfiguration;
    }
}
