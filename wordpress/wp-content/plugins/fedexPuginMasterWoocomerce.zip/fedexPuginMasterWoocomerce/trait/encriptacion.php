<?php

//define('KEY', '8965743632547896'); 

trait encriptacion
{

    function cargaEncritado( $dataToEncode, $key )
    {

        $result = '';
        for ($i = 0; $i < strlen($dataToEncode); $i++) {
            $char = substr($dataToEncode, $i, 1);
            $keychar = substr($key, ($i % strlen($key)) - 1, 1);
            $char = chr(ord($char) + ord($keychar));
            $result .= $char;
        }

        return base64_encode($result);
    }

    function desencriptar($dataTodecrypt, $key )
    {

        $result = '';
        $string = base64_decode($dataTodecrypt);
        for ($i = 0; $i < strlen($string); $i++) {
            $char = substr($string, $i, 1);
            $keychar = substr($key, ($i % strlen($key)) - 1, 1);
            $char = chr(ord($char) - ord($keychar));
            $result .= $char;
        }
        return $result;
    }
}
