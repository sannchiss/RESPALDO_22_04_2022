<?php
require_once PLUGIN_DIR_PATH . 'includes/listaImpresoras.php';

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
  <!-- MDB -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet" />


  <title>Configuracion</title>
</head>

<body>


  <?php if (current_user_can('manage_options')) : #Condicional Alternativa 


  ?>


    <!-- Tabs navs -->
    <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link active" id="ex1-tab-1" data-mdb-toggle="tab" href="#ex1-tabs-1" role="tab" aria-controls="ex1-tabs-1" aria-selected="true">Configuración</a>
      </li>
      <!--  <li class="nav-item" role="presentation">
    <a
      class="nav-link"
      id="ex1-tab-2"
      data-mdb-toggle="tab"
      href="#ex1-tabs-2"
      role="tab"
      aria-controls="ex1-tabs-2"
      aria-selected="false"
      >Tab 2</a
    >
  </li> -->
      <!-- <li class="nav-item" role="presentation">
    <a
      class="nav-link"
      id="ex1-tab-3"
      data-mdb-toggle="tab"
      href="#ex1-tabs-3"
      role="tab"
      aria-controls="ex1-tabs-3"
      aria-selected="false"
      >Tab 3</a
    >
  </li> -->
    </ul>
    <!-- Tabs navs -->

    <!-- Tabs content -->
    <div class="tab-content" id="ex1-content">
      <div class="tab-pane fade show active" id="ex1-tabs-1" role="tabpanel" aria-labelledby="ex1-tab-1">


        <div class="shadow p-3 mb-5 bg-white rounded">

          <div class="container-fluid" style="z-index:1">
            <div class="row">
              <div class="col-7">

                <form class="row g-3" id="creatingConfig">

                  <div class="col-md-4">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" id="cuenta_cliente" name="cuenta_cliente" value="" minlength="9" maxlength="9" required>
                      <label for="cuenta_cliente">CUENTA CORRIENTE</label>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" id="usuario" name="usuario" value="" minlength="6" required>
                      <label for="cuenta_cliente">@USUARIO</label>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-floating mb-3">
                      <input type="password" class="form-control" placeholder="" id="contrasena" name="contrasena" value="" required>
                      <label for="cuenta_cliente">*CONTRASEÑA</label>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-floating">
                      <select class="form-select" id="tipo_entorno" name="tipo_entorno" required aria-label="Floating label select example">
                        <option selected disabled value="">Escoger...</option>
                        <option value="PRE">PRE</option>
                        <option vlaue="PRO">PRO</option>
                      </select>
                      <label for="tipo_entorno">ENTORNO</label>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-floating">
                      <select class="form-select" id="tipo_impresion" name="tipo_impresion" required onchange=mostrarInputimpresora() aria-label="Floating label select example">
                        <option selected disabled value="">Escoger...</option>
                        <option value="PDF">PDF</option>
                        <option value="PDF2">PDF2</option>
                        <option value="EPL">EPL</option>
                        <option value="ZPL">ZPL</option>
                      </select>
                      <label for="tipo_impresion">TIPO DE IMPRESIÓN</label>
                    </div>
                  </div>


                  <div class="col-md-3">
                    <div class="form-floating">
                      <select class="form-select" id="select_bultos" name="select_bultos" required aria-label="Floating label select example">
                        <option selected disabled value="">Escoger...</option>
                        <option value="Si">Si</option>
                        <option value="No">No</option>
                      </select>
                      <label for="tipo_impresion">BULTO POR PEDIDO</label>
                    </div>
                  </div>


                  <div class="col-md-7" id="divImpresora" style="display: none">

                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" id="impresora" name="impresora" value="">
                      <label for="cuenta_cliente">*IMPRESORA</label>
                    </div>

                  </div>



                  <div class="col-12">
                    <button type="submit" class="send_config btn btn-primary">Configurar</button>
                  </div>
                </form>


              </div>

            </div>
          </div>

        </div>

      </div>

      <!-- <div class="tab-pane fade" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
    Tab 2 content
  </div>
  
  <div class="tab-pane fade" id="ex1-tabs-3" role="tabpanel" aria-labelledby="ex1-tab-3">
    Tab 3 content
  </div> -->


    </div>
    <!-- Tabs content -->

  <?php else : ?>
    <p>
      No tienes acceso a esta sección
    </p>
  <?php endif; ?>


  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

  <!-- MDB -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.js"></script>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
</body>


</html>

<script type="text/javascript">
  function mostrarInputimpresora() {

    getSelectValue = document.getElementById("tipo_impresion").value;
    if (getSelectValue == "EPL" || getSelectValue == "ZPL") {


      document.getElementById("divImpresora").style.display = "block";

    } else {

      document.getElementById("divImpresora").style.display = "none";

    }

  }
</script>