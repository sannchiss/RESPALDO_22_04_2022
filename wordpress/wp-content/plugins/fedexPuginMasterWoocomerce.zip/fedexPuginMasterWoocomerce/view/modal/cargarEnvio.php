<div class="modal fade" id="loadEnvio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">DATOS DE ENVÍO<h4><span class="badge badge-warning" id="numberOrder"></span></h4></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form id="creatingSend" autocomplete="off">
          <!-- ------------------------------------------------------------------------------------------------------------- -->
          <div class="row">
            <div class="card-body">
              <div class="row">
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" name="CLIENTE_REFERENCIA" id="CLIENTE_REFERENCIA" readonly>
                      <label for="CLIENTE_REFERENCIA">ORDEN DE COMPRA</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" name="NIF_DESTINATARIO" id="NIF_DESTINATARIO" value="1-9" readonly>
                      <label for="NIF_DESTINATARIO">RUT</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" name="NOMBRE_DESTINATARIO" id="NOMBRE_DESTINATARIO" readonly>
                      <label for="NOMBRE_DESTINATARIO">NOMBRE COMPLETO</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-1 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" name="PAIS_DESTINATARIO" id="PAIS_DESTINATARIO" value="CL" readonly>
                      <label for="PAIS_DESTINATARIO">PAIS</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="" name="PERSONA_CONTACTO_DESTINATARIO" id="PERSONA_CONTACTO_DESTINATARIO" value="CL" maxlength="40">
                      <label for="PERSONA_CONTACTO_DESTINATARIO">CONTACTO</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="typeaheadLocation form-control" placeholder="" name="POBLACION_DESTINATARIO" id="POBLACION_DESTINATARIO" autocomplete="new-text" required>
                      <label for="PERSONA_CONTACTO_DESTINATARIO">POBLACIÓN/COMUNA</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="postalCode form-control" placeholder="CÓDIGO POSTAL" name="CODIGO_POSTAL_DESTINATARIO" id="CODIGO_POSTAL_DESTINATARIO" readonly>
                      <label for="PERSONA_CONTACTO_DESTINATARIO">CÓDIGO POSTAL</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 pr-1">
                  <div class="form-group">
                    <div class="form-floating">
                      <textarea class="form-control" placeholder="" name="DIRECCION_DESTINATARIO" id="DIRECCION_DESTINATARIO" maxlength="40" style="height: 100px" required></textarea>
                      <label for="DIRECCION_DESTINATARIO">DIRECCIÓN</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 pr-1">
                  <div class="form-group">
                    <div class="form-floating">
                      <textarea class="form-control" placeholder="" name="NOTAS_DESTINATARIO" id="NOTAS_DESTINATARIO" maxlength="100" style="height: 100px"></textarea>
                      <label for="NOTAS_DESTINATARIO">NOTAS</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="TELEFONO CONTACTO DESTINATARIOL" value="999999999" name="TELEFONO_CONTACTO_DESTINATARIO" id="TELEFONO_CONTACTO_DESTINATARIO">
                      <label for="TELEFONO_CONTACTO_DESTINATARIO">TLF. CONTACTO</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="email" placeholder="EMAIL DESTINATARIO" value="none@none.com" class="form-control" name="EMAIL_DESTINATARIO" id="EMAIL_DESTINATARIO" autocomplete="new-text" required>
                      <label for="TELEFONO_CONTACTO_DESTINATARIO">EMAIL</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="number" class="form-control" placeholder="NUMERO_BULTOS" name="NUMERO_BULTOS" id="NUMERO_BULTOS" min="0" onKeyDown="limitText(this,3);" onKeyUp="limitText(this,3);" pattern="^[0-9]+" required>
                      <label for="NUMERO_BULTOS">#BULTOS</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="KILOS" value="" name="KILOS" id="KILOS" min="0" onKeyDown="limitText(this,6);" onKeyUp="limitText(this,7);" lang="en" step="0.001" required>
                      <label for="KILOS">#KILOS</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 pr-1">
                  <div class="form-group">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" placeholder="0.01" value="0.01" name="VOLUMEN" id="VOLUMEN" min="0" onKeyDown="limitText(this,4);" onKeyUp="limitText(this,4);" lang="en" step="0.001" required>
                      <label for="VOLUMEN">#VOLUMEN</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            <button type="submit" class="send_order btn btn-primary">Gestionar Envío</button>
          </div>
        </form>
      </div>

    </div>
  </div>
</div>