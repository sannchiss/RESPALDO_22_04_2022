<div class="container">

    <form action="">

        <div class="row">

            <div class="col-md-12">

                <div class="shadow p-3 mb-5 bg-white rounded">

                    <div class="container-fluid" style="z-index:1">

                        <div class="panel-heading">

                            <h3 class="panel-title mb-3">Credenciales</h3>

                        </div>

                        <div class="row">

                            <div class="col-md-5">

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="" id="accountNumber"
                                        name="accountNumber" value="" minlength="9" maxlength="9" required>
                                    <label for="cuenta_cliente">Account Number</label>
                                </div>

                            </div>

                        </div>

                        <!--Meter Number--->

                        <div class="row">

                            <div class="col-md-5">

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="" id="meterNumber"
                                        name="meterNumber" value="" minlength="9" maxlength="9" required>
                                    <label for="cuenta_cliente">Meter Number</label>
                                </div>


                            </div>

                        </div>

                        <!--wskey User Credential--->
                        <div class="row">

                            <div class="col-md-5">

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="" id="wskeyUserCredential"
                                        name="wskeyUserCredential" value="" minlength="9" maxlength="9" required>
                                    <label for="cuenta_cliente">Wskey User Credential</label>
                                </div>


                            </div>

                        </div>

                        <!--wspassword User Credential--->
                        <div class="row">

                            <div class="col-md-5">

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="" id="wspasswordUserCredential"
                                        name="wspasswordUserCredential" value="" minlength="9" maxlength="9" required>
                                    <label for="cuenta_cliente">Wspassword User Credential</label>
                                </div>

                            </div>

                        </div>

                        <hr>

                        <!--service Type--->
                        <div class="row">

                            <div class="panel-heading">

                                <h3 class="panel-title mb-3">Servicios/Tipos de emblaje/Tipo pagador/Impresión/Unidad de
                                    medida</h3>

                            </div>

                            <div class="col-md-3">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="serviceType" name="serviceType" required
                                        onchange=serviceType() aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="ECONOMY">ECONOMY</option>
                                        <option value="STANDARD_OVERNIGHT">STANDARD_OVERNIGHT</option>
                                        <option value="PRIORITY_OVERNIGHT">PRIORITY_OVERNIGHT</option>
                                        <option value="FIRST_OVERNIGHT">FIRST_OVERNIGHT</option>
                                        <option value="FREIGHT_1D">FREIGHT_1D</option>
                                        <option value="FREIGHT_2D">FREIGHT_2D</option>

                                    </select>
                                    <label for="tipo_impresion">Service Type</label>
                                </div>
                            </div>

                            <!--Packaging Type--->
                            <div class="col-md-3">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="packagingType" name="packagingType" required
                                        onchange=serviceType() aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="YOUR_PACKAGING">YOUR_PACKAGING</option>
                                        <option value="FEDEX_ENVELOPE">FEDEX_ENVELOPE</option>
                                        <option value="FEDEX_PAK">FEDEX_PAK</option>
                                        <option value="FEDEX_BOX">FEDEX_BOX</option>
                                        <option value="FEDEX_TUBE">FEDEX_TUBE</option>
                                        <option value="FEDEX_BOX_10">FEDEX_BOX_10</option>
                                        <option value="FEDEX_BOX_25">FEDEX_BOX_25</option>
                                    </select>
                                    <label for="packagingType">Packaging Type</label>
                                </div>
                            </div>

                        </div>

                        <!--label Type--->
                        <div class="row">

                            <div class="col-md-2">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="paymentType" name="paymentType" required
                                        aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="SENDER">SENDER</option>
                                        <option value="RECIPIENT">RECIPIENT</option>
                                        <option value="THIRD_PARTY">THIRD_PARTY</option>
                                    </select>
                                    <label for="paymentType">Payment Type</label>
                                </div>
                            </div>

                            <div class="col-md-2">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="labelType" name="labelType" required
                                        onchange=serviceType() aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="PNG">PNG</option>
                                        <option value="ZPL">ZPL</option>
                                    </select>
                                    <label for="labelType">label Type</label>
                                </div>
                            </div>

                            <div class="col-md-2">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="measurementUnits" name="measurementUnits" required
                                        onchange=serviceType() aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="KG/CM">KG/CM</option>
                                        <option value="LBS/IN">LBS/IN</option>
                                    </select>
                                    <label for="measurementUnits">Measurement Units</label>
                                </div>

                            </div>



                        </div>

                        <hr>
                        <!--Environment--->
                        <div class="row">

                            <div class="panel-heading">

                                <h3 class="panel-title mb-3">Ambiente</h3>

                            </div>

                            <div class="col-md-2">

                                <div class="form-floating mb-3">
                                    <select class="form-select" id="environment" name="environment" required
                                        onchange=serviceType() aria-label="Floating label select example">
                                        <option selected disabled value="">Search...</option>
                                        <option value="REGULAR_PICKUP">QA</option>
                                        <option value="REQUEST_COURIER">PRODUCTION</option>
                                    </select>
                                    <label for="environment">Environment</label>
                                </div>

                            </div>

                        </div>


                        <!-- <div class="row">



                        <div class="col-7">


                            <form class="row g-3" id="creatingConfig">

                                <div class="col-md-4">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="" id="cuenta_cliente"
                                            name="cuenta_cliente" value="" minlength="9" maxlength="9" required>
                                        <label for="cuenta_cliente">CUENTA CORRIENTE</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="" id="usuario"
                                            name="usuario" value="" minlength="6" required>
                                        <label for="cuenta_cliente">@USUARIO</label>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-floating mb-3">
                                        <input type="password" class="form-control" placeholder="" id="contrasena"
                                            name="contrasena" value="" required>
                                        <label for="cuenta_cliente">*CONTRASEÑA</label>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-floating">
                                        <select class="form-select" id="tipo_entorno" name="tipo_entorno" required
                                            aria-label="Floating label select example">
                                            <option selected disabled value="">Escoger...</option>
                                            <option value="PRE">PRE</option>
                                            <option vlaue="PRO">PRO</option>
                                        </select>
                                        <label for="tipo_entorno">ENTORNO</label>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-floating">
                                        <select class="form-select" id="tipo_impresion" name="tipo_impresion" required
                                            onchange=mostrarInputimpresora() aria-label="Floating label select example">
                                            <option selected disabled value="">Escoger...</option>
                                            <option value="PDF">PDF</option>
                                            <option value="PDF2">PDF2</option>
                                            <option value="EPL">EPL</option>
                                            <option value="ZPL">ZPL</option>
                                        </select>
                                        <label for="tipo_impresion">TIPO DE IMPRESIÓN</label>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-floating">
                                        <select class="form-select" id="select_bultos" name="select_bultos" required
                                            aria-label="Floating label select example">
                                            <option selected disabled value="">Escoger...</option>
                                            <option value="Si">Si</option>
                                            <option value="No">No</option>
                                        </select>
                                        <label for="tipo_impresion">BULTO POR PEDIDO</label>
                                    </div>
                                </div>


                                <div class="col-md-7" id="divImpresora" style="display: none">

                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="" id="impresora"
                                            name="impresora" value="">
                                        <label for="cuenta_cliente">*IMPRESORA</label>
                                    </div>

                                </div>



                                <div class="col-12">
                                    <button type="submit" class="send_config btn btn-primary">Configurar</button>
                                </div>
                            </form>


                        </div>

                    </div> -->
                    </div>

                    <hr>


                    <div class="footer">

                        <div class="container">

                            <div class="row">

                                <div class="col-md-12">

                                    <div class="footer">
                                        <button type="submit" class="send_config btn btn-primary">Guardar</button>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>
        </div>


    </form>




</div>